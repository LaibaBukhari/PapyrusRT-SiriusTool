/**
 */
package papyrusrt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.State#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.State#getEntryAction <em>Entry Action</em>}</li>
 *   <li>{@link papyrusrt.State#getExitAction <em>Exit Action</em>}</li>
 *   <li>{@link papyrusrt.State#getInternalTransition <em>Internal Transition</em>}</li>
 *   <li>{@link papyrusrt.State#getEntrypoint <em>Entrypoint</em>}</li>
 *   <li>{@link papyrusrt.State#getExitpoint <em>Exitpoint</em>}</li>
 *   <li>{@link papyrusrt.State#getTransition <em>Transition</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getState()
 * @model
 * @generated
 */
public interface State extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see papyrusrt.PapyrusrtPackage#getState_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link papyrusrt.State#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Entry Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entry Action</em>' attribute.
	 * @see #setEntryAction(String)
	 * @see papyrusrt.PapyrusrtPackage#getState_EntryAction()
	 * @model
	 * @generated
	 */
	String getEntryAction();

	/**
	 * Sets the value of the '{@link papyrusrt.State#getEntryAction <em>Entry Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entry Action</em>' attribute.
	 * @see #getEntryAction()
	 * @generated
	 */
	void setEntryAction(String value);

	/**
	 * Returns the value of the '<em><b>Exit Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exit Action</em>' attribute.
	 * @see #setExitAction(String)
	 * @see papyrusrt.PapyrusrtPackage#getState_ExitAction()
	 * @model
	 * @generated
	 */
	String getExitAction();

	/**
	 * Sets the value of the '{@link papyrusrt.State#getExitAction <em>Exit Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Exit Action</em>' attribute.
	 * @see #getExitAction()
	 * @generated
	 */
	void setExitAction(String value);

	/**
	 * Returns the value of the '<em><b>Internal Transition</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Internal Transition</em>' attribute.
	 * @see #setInternalTransition(String)
	 * @see papyrusrt.PapyrusrtPackage#getState_InternalTransition()
	 * @model
	 * @generated
	 */
	String getInternalTransition();

	/**
	 * Sets the value of the '{@link papyrusrt.State#getInternalTransition <em>Internal Transition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Internal Transition</em>' attribute.
	 * @see #getInternalTransition()
	 * @generated
	 */
	void setInternalTransition(String value);

	/**
	 * Returns the value of the '<em><b>Entrypoint</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.EntryPoint}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entrypoint</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getState_Entrypoint()
	 * @model containment="true"
	 * @generated
	 */
	EList<EntryPoint> getEntrypoint();

	/**
	 * Returns the value of the '<em><b>Exitpoint</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.ExitPoint}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exitpoint</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getState_Exitpoint()
	 * @model containment="true"
	 * @generated
	 */
	EList<ExitPoint> getExitpoint();

	/**
	 * Returns the value of the '<em><b>Transition</b></em>' reference list.
	 * The list contents are of type {@link papyrusrt.Transition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transition</em>' reference list.
	 * @see papyrusrt.PapyrusrtPackage#getState_Transition()
	 * @model
	 * @generated
	 */
	EList<Transition> getTransition();

} // State
