/**
 */
package papyrusrt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State Machine</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.StateMachine#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getRegion <em>Region</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getInitialstate <em>Initialstate</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getState <em>State</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getTransition <em>Transition</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getChoice <em>Choice</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getDeephistory <em>Deephistory</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getJunction <em>Junction</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getTrans <em>Trans</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getExitpoint <em>Exitpoint</em>}</li>
 *   <li>{@link papyrusrt.StateMachine#getEntrypoint <em>Entrypoint</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getStateMachine()
 * @model
 * @generated
 */
public interface StateMachine extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * The default value is <code>""</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Name()
	 * @model default=""
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link papyrusrt.StateMachine#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Region</b></em>' attribute.
	 * The default value is <code>"Region1"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Region</em>' attribute.
	 * @see #setRegion(String)
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Region()
	 * @model default="Region1"
	 * @generated
	 */
	String getRegion();

	/**
	 * Sets the value of the '{@link papyrusrt.StateMachine#getRegion <em>Region</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Region</em>' attribute.
	 * @see #getRegion()
	 * @generated
	 */
	void setRegion(String value);

	/**
	 * Returns the value of the '<em><b>Initialstate</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initialstate</em>' containment reference.
	 * @see #setInitialstate(InitialState)
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Initialstate()
	 * @model containment="true"
	 * @generated
	 */
	InitialState getInitialstate();

	/**
	 * Sets the value of the '{@link papyrusrt.StateMachine#getInitialstate <em>Initialstate</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Initialstate</em>' containment reference.
	 * @see #getInitialstate()
	 * @generated
	 */
	void setInitialstate(InitialState value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.State}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_State()
	 * @model containment="true"
	 * @generated
	 */
	EList<State> getState();

	/**
	 * Returns the value of the '<em><b>Transition</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Transition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transition</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Transition()
	 * @model containment="true"
	 * @generated
	 */
	EList<Transition> getTransition();

	/**
	 * Returns the value of the '<em><b>Choice</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Choice}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Choice</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Choice()
	 * @model containment="true"
	 * @generated
	 */
	EList<Choice> getChoice();

	/**
	 * Returns the value of the '<em><b>Deephistory</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.DeepHistory}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Deephistory</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Deephistory()
	 * @model containment="true"
	 * @generated
	 */
	EList<DeepHistory> getDeephistory();

	/**
	 * Returns the value of the '<em><b>Junction</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Junction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Junction</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Junction()
	 * @model containment="true"
	 * @generated
	 */
	EList<Junction> getJunction();

	/**
	 * Returns the value of the '<em><b>Trans</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Trans}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trans</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Trans()
	 * @model containment="true"
	 * @generated
	 */
	EList<Trans> getTrans();

	/**
	 * Returns the value of the '<em><b>Exitpoint</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.ExitPoint}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exitpoint</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Exitpoint()
	 * @model containment="true"
	 * @generated
	 */
	EList<ExitPoint> getExitpoint();

	/**
	 * Returns the value of the '<em><b>Entrypoint</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.EntryPoint}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entrypoint</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getStateMachine_Entrypoint()
	 * @model containment="true"
	 * @generated
	 */
	EList<EntryPoint> getEntrypoint();

} // StateMachine
