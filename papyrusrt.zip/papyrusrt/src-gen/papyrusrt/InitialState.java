/**
 */
package papyrusrt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Initial State</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.InitialState#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.InitialState#getTransition <em>Transition</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getInitialState()
 * @model
 * @generated
 */
public interface InitialState extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see papyrusrt.PapyrusrtPackage#getInitialState_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link papyrusrt.InitialState#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Transition</b></em>' reference list.
	 * The list contents are of type {@link papyrusrt.Transition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transition</em>' reference list.
	 * @see papyrusrt.PapyrusrtPackage#getInitialState_Transition()
	 * @model
	 * @generated
	 */
	EList<Transition> getTransition();

} // InitialState
