/**
 */
package papyrusrt.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

import papyrusrt.*;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class PapyrusrtFactoryImpl extends EFactoryImpl implements PapyrusrtFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PapyrusrtFactory init() {
		try {
			PapyrusrtFactory thePapyrusrtFactory = (PapyrusrtFactory) EPackage.Registry.INSTANCE
					.getEFactory(PapyrusrtPackage.eNS_URI);
			if (thePapyrusrtFactory != null) {
				return thePapyrusrtFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new PapyrusrtFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PapyrusrtFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case PapyrusrtPackage.TOP_CAPSULE:
			return createTopCapsule();
		case PapyrusrtPackage.CAPSULE_PART:
			return createCapsulePart();
		case PapyrusrtPackage.SELECT_PORT:
			return createSelectPort();
		case PapyrusrtPackage.PROTOCOL:
			return createProtocol();
		case PapyrusrtPackage.OUTMESSAGE:
			return createOutmessage();
		case PapyrusrtPackage.INMESSAGE:
			return createInmessage();
		case PapyrusrtPackage.INOUTMESSAGE:
			return createInoutmessage();
		case PapyrusrtPackage.CONJUGATE_PORT:
			return createConjugatePort();
		case PapyrusrtPackage.NONCONJUGATE_PORT:
			return createNonconjugatePort();
		case PapyrusrtPackage.FRAME_PORT:
			return createFramePort();
		case PapyrusrtPackage.LOG_PORT:
			return createLogPort();
		case PapyrusrtPackage.TIMING_PORT:
			return createTimingPort();
		case PapyrusrtPackage.STATE_MACHINE:
			return createStateMachine();
		case PapyrusrtPackage.STATE:
			return createState();
		case PapyrusrtPackage.ENTRY_POINT:
			return createEntryPoint();
		case PapyrusrtPackage.EXIT_POINT:
			return createExitPoint();
		case PapyrusrtPackage.INITIAL_STATE:
			return createInitialState();
		case PapyrusrtPackage.TRANSITION:
			return createTransition();
		case PapyrusrtPackage.CHOICE:
			return createChoice();
		case PapyrusrtPackage.DEEP_HISTORY:
			return createDeepHistory();
		case PapyrusrtPackage.JUNCTION:
			return createJunction();
		case PapyrusrtPackage.TRIGGER:
			return createTrigger();
		case PapyrusrtPackage.TRANS:
			return createTrans();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL:
			return createPapyrusRTModel();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TopCapsule createTopCapsule() {
		TopCapsuleImpl topCapsule = new TopCapsuleImpl();
		return topCapsule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CapsulePart createCapsulePart() {
		CapsulePartImpl capsulePart = new CapsulePartImpl();
		return capsulePart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SelectPort createSelectPort() {
		SelectPortImpl selectPort = new SelectPortImpl();
		return selectPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Protocol createProtocol() {
		ProtocolImpl protocol = new ProtocolImpl();
		return protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Outmessage createOutmessage() {
		OutmessageImpl outmessage = new OutmessageImpl();
		return outmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Inmessage createInmessage() {
		InmessageImpl inmessage = new InmessageImpl();
		return inmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Inoutmessage createInoutmessage() {
		InoutmessageImpl inoutmessage = new InoutmessageImpl();
		return inoutmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConjugatePort createConjugatePort() {
		ConjugatePortImpl conjugatePort = new ConjugatePortImpl();
		return conjugatePort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NonconjugatePort createNonconjugatePort() {
		NonconjugatePortImpl nonconjugatePort = new NonconjugatePortImpl();
		return nonconjugatePort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FramePort createFramePort() {
		FramePortImpl framePort = new FramePortImpl();
		return framePort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public LogPort createLogPort() {
		LogPortImpl logPort = new LogPortImpl();
		return logPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TimingPort createTimingPort() {
		TimingPortImpl timingPort = new TimingPortImpl();
		return timingPort;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StateMachine createStateMachine() {
		StateMachineImpl stateMachine = new StateMachineImpl();
		return stateMachine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State createState() {
		StateImpl state = new StateImpl();
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EntryPoint createEntryPoint() {
		EntryPointImpl entryPoint = new EntryPointImpl();
		return entryPoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExitPoint createExitPoint() {
		ExitPointImpl exitPoint = new ExitPointImpl();
		return exitPoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InitialState createInitialState() {
		InitialStateImpl initialState = new InitialStateImpl();
		return initialState;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transition createTransition() {
		TransitionImpl transition = new TransitionImpl();
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Choice createChoice() {
		ChoiceImpl choice = new ChoiceImpl();
		return choice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeepHistory createDeepHistory() {
		DeepHistoryImpl deepHistory = new DeepHistoryImpl();
		return deepHistory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Junction createJunction() {
		JunctionImpl junction = new JunctionImpl();
		return junction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trigger createTrigger() {
		TriggerImpl trigger = new TriggerImpl();
		return trigger;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trans createTrans() {
		TransImpl trans = new TransImpl();
		return trans;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PapyrusRTModel createPapyrusRTModel() {
		PapyrusRTModelImpl papyrusRTModel = new PapyrusRTModelImpl();
		return papyrusRTModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PapyrusrtPackage getPapyrusrtPackage() {
		return (PapyrusrtPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static PapyrusrtPackage getPackage() {
		return PapyrusrtPackage.eINSTANCE;
	}

} //PapyrusrtFactoryImpl
