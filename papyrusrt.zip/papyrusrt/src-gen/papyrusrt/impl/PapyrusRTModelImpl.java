/**
 */
package papyrusrt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import papyrusrt.CapsulePart;
import papyrusrt.Choice;
import papyrusrt.DeepHistory;
import papyrusrt.EntryPoint;
import papyrusrt.ExitPoint;
import papyrusrt.InitialState;
import papyrusrt.Inmessage;
import papyrusrt.Inoutmessage;
import papyrusrt.Junction;
import papyrusrt.Outmessage;
import papyrusrt.PapyrusRTModel;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.Protocol;
import papyrusrt.SelectPort;
import papyrusrt.State;
import papyrusrt.StateMachine;
import papyrusrt.TopCapsule;
import papyrusrt.Trans;
import papyrusrt.Transition;
import papyrusrt.Trigger;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Papyrus RT Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getTopcapsule <em>Topcapsule</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getStatemachine <em>Statemachine</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getCapsulepart <em>Capsulepart</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getInitialstate <em>Initialstate</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getState <em>State</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getEntrypoint <em>Entrypoint</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getExitpoint <em>Exitpoint</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getTransition <em>Transition</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getTrigger <em>Trigger</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getJunction <em>Junction</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getDeephistory <em>Deephistory</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getTrans <em>Trans</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getOutmessage <em>Outmessage</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getInoutmessage <em>Inoutmessage</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getInmessage <em>Inmessage</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getChoice <em>Choice</em>}</li>
 *   <li>{@link papyrusrt.impl.PapyrusRTModelImpl#getPort <em>Port</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PapyrusRTModelImpl extends MinimalEObjectImpl.Container implements PapyrusRTModel {
	/**
	 * The cached value of the '{@link #getProtocol() <em>Protocol</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocol()
	 * @generated
	 * @ordered
	 */
	protected EList<Protocol> protocol;

	/**
	 * The cached value of the '{@link #getTopcapsule() <em>Topcapsule</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTopcapsule()
	 * @generated
	 * @ordered
	 */
	protected EList<TopCapsule> topcapsule;

	/**
	 * The cached value of the '{@link #getStatemachine() <em>Statemachine</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStatemachine()
	 * @generated
	 * @ordered
	 */
	protected EList<StateMachine> statemachine;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCapsulepart() <em>Capsulepart</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapsulepart()
	 * @generated
	 * @ordered
	 */
	protected EList<CapsulePart> capsulepart;

	/**
	 * The cached value of the '{@link #getInitialstate() <em>Initialstate</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialstate()
	 * @generated
	 * @ordered
	 */
	protected EList<InitialState> initialstate;

	/**
	 * The cached value of the '{@link #getState() <em>State</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState()
	 * @generated
	 * @ordered
	 */
	protected EList<State> state;

	/**
	 * The cached value of the '{@link #getEntrypoint() <em>Entrypoint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntrypoint()
	 * @generated
	 * @ordered
	 */
	protected EList<EntryPoint> entrypoint;

	/**
	 * The cached value of the '{@link #getExitpoint() <em>Exitpoint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExitpoint()
	 * @generated
	 * @ordered
	 */
	protected EList<ExitPoint> exitpoint;

	/**
	 * The cached value of the '{@link #getTransition() <em>Transition</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransition()
	 * @generated
	 * @ordered
	 */
	protected EList<Transition> transition;

	/**
	 * The cached value of the '{@link #getTrigger() <em>Trigger</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrigger()
	 * @generated
	 * @ordered
	 */
	protected EList<Trigger> trigger;

	/**
	 * The cached value of the '{@link #getJunction() <em>Junction</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJunction()
	 * @generated
	 * @ordered
	 */
	protected EList<Junction> junction;

	/**
	 * The cached value of the '{@link #getDeephistory() <em>Deephistory</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeephistory()
	 * @generated
	 * @ordered
	 */
	protected EList<DeepHistory> deephistory;

	/**
	 * The cached value of the '{@link #getTrans() <em>Trans</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrans()
	 * @generated
	 * @ordered
	 */
	protected EList<Trans> trans;

	/**
	 * The cached value of the '{@link #getOutmessage() <em>Outmessage</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Outmessage> outmessage;

	/**
	 * The cached value of the '{@link #getInoutmessage() <em>Inoutmessage</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInoutmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Inoutmessage> inoutmessage;

	/**
	 * The cached value of the '{@link #getInmessage() <em>Inmessage</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Inmessage> inmessage;

	/**
	 * The cached value of the '{@link #getChoice() <em>Choice</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChoice()
	 * @generated
	 * @ordered
	 */
	protected EList<Choice> choice;

	/**
	 * The cached value of the '{@link #getPort() <em>Port</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPort()
	 * @generated
	 * @ordered
	 */
	protected EList<SelectPort> port;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PapyrusRTModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.PAPYRUS_RT_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Protocol> getProtocol() {
		if (protocol == null) {
			protocol = new EObjectContainmentEList<Protocol>(Protocol.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__PROTOCOL);
		}
		return protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TopCapsule> getTopcapsule() {
		if (topcapsule == null) {
			topcapsule = new EObjectContainmentEList<TopCapsule>(TopCapsule.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__TOPCAPSULE);
		}
		return topcapsule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StateMachine> getStatemachine() {
		if (statemachine == null) {
			statemachine = new EObjectContainmentEList<StateMachine>(StateMachine.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__STATEMACHINE);
		}
		return statemachine;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.PAPYRUS_RT_MODEL__NAME, oldName,
					name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CapsulePart> getCapsulepart() {
		if (capsulepart == null) {
			capsulepart = new EObjectContainmentEList<CapsulePart>(CapsulePart.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__CAPSULEPART);
		}
		return capsulepart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<InitialState> getInitialstate() {
		if (initialstate == null) {
			initialstate = new EObjectContainmentEList<InitialState>(InitialState.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__INITIALSTATE);
		}
		return initialstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<State> getState() {
		if (state == null) {
			state = new EObjectContainmentEList<State>(State.class, this, PapyrusrtPackage.PAPYRUS_RT_MODEL__STATE);
		}
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EntryPoint> getEntrypoint() {
		if (entrypoint == null) {
			entrypoint = new EObjectContainmentEList<EntryPoint>(EntryPoint.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__ENTRYPOINT);
		}
		return entrypoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ExitPoint> getExitpoint() {
		if (exitpoint == null) {
			exitpoint = new EObjectContainmentEList<ExitPoint>(ExitPoint.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__EXITPOINT);
		}
		return exitpoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Transition> getTransition() {
		if (transition == null) {
			transition = new EObjectContainmentEList<Transition>(Transition.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANSITION);
		}
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Trigger> getTrigger() {
		if (trigger == null) {
			trigger = new EObjectContainmentEList<Trigger>(Trigger.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__TRIGGER);
		}
		return trigger;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Junction> getJunction() {
		if (junction == null) {
			junction = new EObjectContainmentEList<Junction>(Junction.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__JUNCTION);
		}
		return junction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DeepHistory> getDeephistory() {
		if (deephistory == null) {
			deephistory = new EObjectContainmentEList<DeepHistory>(DeepHistory.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__DEEPHISTORY);
		}
		return deephistory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Trans> getTrans() {
		if (trans == null) {
			trans = new EObjectContainmentEList<Trans>(Trans.class, this, PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANS);
		}
		return trans;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Outmessage> getOutmessage() {
		if (outmessage == null) {
			outmessage = new EObjectContainmentEList<Outmessage>(Outmessage.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__OUTMESSAGE);
		}
		return outmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Inoutmessage> getInoutmessage() {
		if (inoutmessage == null) {
			inoutmessage = new EObjectContainmentEList<Inoutmessage>(Inoutmessage.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__INOUTMESSAGE);
		}
		return inoutmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Inmessage> getInmessage() {
		if (inmessage == null) {
			inmessage = new EObjectContainmentEList<Inmessage>(Inmessage.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__INMESSAGE);
		}
		return inmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Choice> getChoice() {
		if (choice == null) {
			choice = new EObjectContainmentEList<Choice>(Choice.class, this, PapyrusrtPackage.PAPYRUS_RT_MODEL__CHOICE);
		}
		return choice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SelectPort> getPort() {
		if (port == null) {
			port = new EObjectContainmentEList<SelectPort>(SelectPort.class, this,
					PapyrusrtPackage.PAPYRUS_RT_MODEL__PORT);
		}
		return port;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PROTOCOL:
			return ((InternalEList<?>) getProtocol()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TOPCAPSULE:
			return ((InternalEList<?>) getTopcapsule()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATEMACHINE:
			return ((InternalEList<?>) getStatemachine()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CAPSULEPART:
			return ((InternalEList<?>) getCapsulepart()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INITIALSTATE:
			return ((InternalEList<?>) getInitialstate()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATE:
			return ((InternalEList<?>) getState()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__ENTRYPOINT:
			return ((InternalEList<?>) getEntrypoint()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__EXITPOINT:
			return ((InternalEList<?>) getExitpoint()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANSITION:
			return ((InternalEList<?>) getTransition()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRIGGER:
			return ((InternalEList<?>) getTrigger()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__JUNCTION:
			return ((InternalEList<?>) getJunction()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__DEEPHISTORY:
			return ((InternalEList<?>) getDeephistory()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANS:
			return ((InternalEList<?>) getTrans()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__OUTMESSAGE:
			return ((InternalEList<?>) getOutmessage()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INOUTMESSAGE:
			return ((InternalEList<?>) getInoutmessage()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INMESSAGE:
			return ((InternalEList<?>) getInmessage()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CHOICE:
			return ((InternalEList<?>) getChoice()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PORT:
			return ((InternalEList<?>) getPort()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PROTOCOL:
			return getProtocol();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TOPCAPSULE:
			return getTopcapsule();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATEMACHINE:
			return getStatemachine();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__NAME:
			return getName();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CAPSULEPART:
			return getCapsulepart();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INITIALSTATE:
			return getInitialstate();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATE:
			return getState();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__ENTRYPOINT:
			return getEntrypoint();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__EXITPOINT:
			return getExitpoint();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANSITION:
			return getTransition();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRIGGER:
			return getTrigger();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__JUNCTION:
			return getJunction();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__DEEPHISTORY:
			return getDeephistory();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANS:
			return getTrans();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__OUTMESSAGE:
			return getOutmessage();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INOUTMESSAGE:
			return getInoutmessage();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INMESSAGE:
			return getInmessage();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CHOICE:
			return getChoice();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PORT:
			return getPort();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PROTOCOL:
			getProtocol().clear();
			getProtocol().addAll((Collection<? extends Protocol>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TOPCAPSULE:
			getTopcapsule().clear();
			getTopcapsule().addAll((Collection<? extends TopCapsule>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATEMACHINE:
			getStatemachine().clear();
			getStatemachine().addAll((Collection<? extends StateMachine>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__NAME:
			setName((String) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CAPSULEPART:
			getCapsulepart().clear();
			getCapsulepart().addAll((Collection<? extends CapsulePart>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INITIALSTATE:
			getInitialstate().clear();
			getInitialstate().addAll((Collection<? extends InitialState>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATE:
			getState().clear();
			getState().addAll((Collection<? extends State>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__ENTRYPOINT:
			getEntrypoint().clear();
			getEntrypoint().addAll((Collection<? extends EntryPoint>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__EXITPOINT:
			getExitpoint().clear();
			getExitpoint().addAll((Collection<? extends ExitPoint>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANSITION:
			getTransition().clear();
			getTransition().addAll((Collection<? extends Transition>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRIGGER:
			getTrigger().clear();
			getTrigger().addAll((Collection<? extends Trigger>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__JUNCTION:
			getJunction().clear();
			getJunction().addAll((Collection<? extends Junction>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__DEEPHISTORY:
			getDeephistory().clear();
			getDeephistory().addAll((Collection<? extends DeepHistory>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANS:
			getTrans().clear();
			getTrans().addAll((Collection<? extends Trans>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__OUTMESSAGE:
			getOutmessage().clear();
			getOutmessage().addAll((Collection<? extends Outmessage>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INOUTMESSAGE:
			getInoutmessage().clear();
			getInoutmessage().addAll((Collection<? extends Inoutmessage>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INMESSAGE:
			getInmessage().clear();
			getInmessage().addAll((Collection<? extends Inmessage>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CHOICE:
			getChoice().clear();
			getChoice().addAll((Collection<? extends Choice>) newValue);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PORT:
			getPort().clear();
			getPort().addAll((Collection<? extends SelectPort>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PROTOCOL:
			getProtocol().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TOPCAPSULE:
			getTopcapsule().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATEMACHINE:
			getStatemachine().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CAPSULEPART:
			getCapsulepart().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INITIALSTATE:
			getInitialstate().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATE:
			getState().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__ENTRYPOINT:
			getEntrypoint().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__EXITPOINT:
			getExitpoint().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANSITION:
			getTransition().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRIGGER:
			getTrigger().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__JUNCTION:
			getJunction().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__DEEPHISTORY:
			getDeephistory().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANS:
			getTrans().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__OUTMESSAGE:
			getOutmessage().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INOUTMESSAGE:
			getInoutmessage().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INMESSAGE:
			getInmessage().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CHOICE:
			getChoice().clear();
			return;
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PORT:
			getPort().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PROTOCOL:
			return protocol != null && !protocol.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TOPCAPSULE:
			return topcapsule != null && !topcapsule.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATEMACHINE:
			return statemachine != null && !statemachine.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CAPSULEPART:
			return capsulepart != null && !capsulepart.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INITIALSTATE:
			return initialstate != null && !initialstate.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__STATE:
			return state != null && !state.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__ENTRYPOINT:
			return entrypoint != null && !entrypoint.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__EXITPOINT:
			return exitpoint != null && !exitpoint.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANSITION:
			return transition != null && !transition.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRIGGER:
			return trigger != null && !trigger.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__JUNCTION:
			return junction != null && !junction.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__DEEPHISTORY:
			return deephistory != null && !deephistory.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__TRANS:
			return trans != null && !trans.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__OUTMESSAGE:
			return outmessage != null && !outmessage.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INOUTMESSAGE:
			return inoutmessage != null && !inoutmessage.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__INMESSAGE:
			return inmessage != null && !inmessage.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__CHOICE:
			return choice != null && !choice.isEmpty();
		case PapyrusrtPackage.PAPYRUS_RT_MODEL__PORT:
			return port != null && !port.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //PapyrusRTModelImpl
