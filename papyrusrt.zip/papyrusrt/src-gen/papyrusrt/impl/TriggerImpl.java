/**
 */
package papyrusrt.impl;

import java.util.Collection;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import papyrusrt.Inmessage;
import papyrusrt.Inoutmessage;
import papyrusrt.Outmessage;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.SelectPort;
import papyrusrt.Trigger;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Trigger</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.TriggerImpl#getPorts <em>Ports</em>}</li>
 *   <li>{@link papyrusrt.impl.TriggerImpl#getOutmessage <em>Outmessage</em>}</li>
 *   <li>{@link papyrusrt.impl.TriggerImpl#getInoutmessage <em>Inoutmessage</em>}</li>
 *   <li>{@link papyrusrt.impl.TriggerImpl#getInmessage <em>Inmessage</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TriggerImpl extends MinimalEObjectImpl.Container implements Trigger {
	/**
	 * The cached value of the '{@link #getPorts() <em>Ports</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPorts()
	 * @generated
	 * @ordered
	 */
	protected EList<SelectPort> ports;

	/**
	 * The cached value of the '{@link #getOutmessage() <em>Outmessage</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Outmessage> outmessage;

	/**
	 * The cached value of the '{@link #getInoutmessage() <em>Inoutmessage</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInoutmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Inoutmessage> inoutmessage;

	/**
	 * The cached value of the '{@link #getInmessage() <em>Inmessage</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Inmessage> inmessage;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TriggerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.TRIGGER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SelectPort> getPorts() {
		if (ports == null) {
			ports = new EObjectResolvingEList<SelectPort>(SelectPort.class, this, PapyrusrtPackage.TRIGGER__PORTS);
		}
		return ports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Outmessage> getOutmessage() {
		if (outmessage == null) {
			outmessage = new EObjectResolvingEList<Outmessage>(Outmessage.class, this,
					PapyrusrtPackage.TRIGGER__OUTMESSAGE);
		}
		return outmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Inoutmessage> getInoutmessage() {
		if (inoutmessage == null) {
			inoutmessage = new EObjectResolvingEList<Inoutmessage>(Inoutmessage.class, this,
					PapyrusrtPackage.TRIGGER__INOUTMESSAGE);
		}
		return inoutmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Inmessage> getInmessage() {
		if (inmessage == null) {
			inmessage = new EObjectResolvingEList<Inmessage>(Inmessage.class, this,
					PapyrusrtPackage.TRIGGER__INMESSAGE);
		}
		return inmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.TRIGGER__PORTS:
			return getPorts();
		case PapyrusrtPackage.TRIGGER__OUTMESSAGE:
			return getOutmessage();
		case PapyrusrtPackage.TRIGGER__INOUTMESSAGE:
			return getInoutmessage();
		case PapyrusrtPackage.TRIGGER__INMESSAGE:
			return getInmessage();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.TRIGGER__PORTS:
			getPorts().clear();
			getPorts().addAll((Collection<? extends SelectPort>) newValue);
			return;
		case PapyrusrtPackage.TRIGGER__OUTMESSAGE:
			getOutmessage().clear();
			getOutmessage().addAll((Collection<? extends Outmessage>) newValue);
			return;
		case PapyrusrtPackage.TRIGGER__INOUTMESSAGE:
			getInoutmessage().clear();
			getInoutmessage().addAll((Collection<? extends Inoutmessage>) newValue);
			return;
		case PapyrusrtPackage.TRIGGER__INMESSAGE:
			getInmessage().clear();
			getInmessage().addAll((Collection<? extends Inmessage>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.TRIGGER__PORTS:
			getPorts().clear();
			return;
		case PapyrusrtPackage.TRIGGER__OUTMESSAGE:
			getOutmessage().clear();
			return;
		case PapyrusrtPackage.TRIGGER__INOUTMESSAGE:
			getInoutmessage().clear();
			return;
		case PapyrusrtPackage.TRIGGER__INMESSAGE:
			getInmessage().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.TRIGGER__PORTS:
			return ports != null && !ports.isEmpty();
		case PapyrusrtPackage.TRIGGER__OUTMESSAGE:
			return outmessage != null && !outmessage.isEmpty();
		case PapyrusrtPackage.TRIGGER__INOUTMESSAGE:
			return inoutmessage != null && !inoutmessage.isEmpty();
		case PapyrusrtPackage.TRIGGER__INMESSAGE:
			return inmessage != null && !inmessage.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //TriggerImpl
