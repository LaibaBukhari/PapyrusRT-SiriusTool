/**
 */
package papyrusrt.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import papyrusrt.LogPort;
import papyrusrt.PapyrusrtPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Log Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.LogPortImpl#getLogName <em>Log Name</em>}</li>
 *   <li>{@link papyrusrt.impl.LogPortImpl#getSystemProtocol <em>System Protocol</em>}</li>
 * </ul>
 *
 * @generated
 */
public class LogPortImpl extends SelectPortImpl implements LogPort {
	/**
	 * The default value of the '{@link #getLogName() <em>Log Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLogName()
	 * @generated
	 * @ordered
	 */
	protected static final String LOG_NAME_EDEFAULT = "Log";

	/**
	 * The cached value of the '{@link #getLogName() <em>Log Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLogName()
	 * @generated
	 * @ordered
	 */
	protected String logName = LOG_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSystemProtocol() <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSystemProtocol()
	 * @generated
	 * @ordered
	 */
	protected static final String SYSTEM_PROTOCOL_EDEFAULT = "Log";

	/**
	 * The cached value of the '{@link #getSystemProtocol() <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSystemProtocol()
	 * @generated
	 * @ordered
	 */
	protected String systemProtocol = SYSTEM_PROTOCOL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LogPortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.LOG_PORT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLogName() {
		return logName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLogName(String newLogName) {
		String oldLogName = logName;
		logName = newLogName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.LOG_PORT__LOG_NAME, oldLogName,
					logName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSystemProtocol() {
		return systemProtocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSystemProtocol(String newSystemProtocol) {
		String oldSystemProtocol = systemProtocol;
		systemProtocol = newSystemProtocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.LOG_PORT__SYSTEM_PROTOCOL,
					oldSystemProtocol, systemProtocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.LOG_PORT__LOG_NAME:
			return getLogName();
		case PapyrusrtPackage.LOG_PORT__SYSTEM_PROTOCOL:
			return getSystemProtocol();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.LOG_PORT__LOG_NAME:
			setLogName((String) newValue);
			return;
		case PapyrusrtPackage.LOG_PORT__SYSTEM_PROTOCOL:
			setSystemProtocol((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.LOG_PORT__LOG_NAME:
			setLogName(LOG_NAME_EDEFAULT);
			return;
		case PapyrusrtPackage.LOG_PORT__SYSTEM_PROTOCOL:
			setSystemProtocol(SYSTEM_PROTOCOL_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.LOG_PORT__LOG_NAME:
			return LOG_NAME_EDEFAULT == null ? logName != null : !LOG_NAME_EDEFAULT.equals(logName);
		case PapyrusrtPackage.LOG_PORT__SYSTEM_PROTOCOL:
			return SYSTEM_PROTOCOL_EDEFAULT == null ? systemProtocol != null
					: !SYSTEM_PROTOCOL_EDEFAULT.equals(systemProtocol);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (LogName: ");
		result.append(logName);
		result.append(", SystemProtocol: ");
		result.append(systemProtocol);
		result.append(')');
		return result.toString();
	}

} //LogPortImpl
