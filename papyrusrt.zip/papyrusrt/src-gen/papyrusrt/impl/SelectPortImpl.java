/**
 */
package papyrusrt.impl;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.SelectPort;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Select Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SelectPortImpl extends MinimalEObjectImpl.Container implements SelectPort {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SelectPortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.SELECT_PORT;
	}

} //SelectPortImpl
