/**
 */
package papyrusrt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import papyrusrt.CapsulePart;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.SelectPort;
import papyrusrt.TopCapsule;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Top Capsule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.TopCapsuleImpl#getCapsulepart <em>Capsulepart</em>}</li>
 *   <li>{@link papyrusrt.impl.TopCapsuleImpl#getPorts <em>Ports</em>}</li>
 *   <li>{@link papyrusrt.impl.TopCapsuleImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TopCapsuleImpl extends MinimalEObjectImpl.Container implements TopCapsule {
	/**
	 * The cached value of the '{@link #getCapsulepart() <em>Capsulepart</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCapsulepart()
	 * @generated
	 * @ordered
	 */
	protected EList<CapsulePart> capsulepart;

	/**
	 * The cached value of the '{@link #getPorts() <em>Ports</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPorts()
	 * @generated
	 * @ordered
	 */
	protected EList<SelectPort> ports;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TopCapsuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.TOP_CAPSULE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CapsulePart> getCapsulepart() {
		if (capsulepart == null) {
			capsulepart = new EObjectContainmentEList<CapsulePart>(CapsulePart.class, this,
					PapyrusrtPackage.TOP_CAPSULE__CAPSULEPART);
		}
		return capsulepart;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SelectPort> getPorts() {
		if (ports == null) {
			ports = new EObjectContainmentEList<SelectPort>(SelectPort.class, this,
					PapyrusrtPackage.TOP_CAPSULE__PORTS);
		}
		return ports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TOP_CAPSULE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.TOP_CAPSULE__CAPSULEPART:
			return ((InternalEList<?>) getCapsulepart()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.TOP_CAPSULE__PORTS:
			return ((InternalEList<?>) getPorts()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.TOP_CAPSULE__CAPSULEPART:
			return getCapsulepart();
		case PapyrusrtPackage.TOP_CAPSULE__PORTS:
			return getPorts();
		case PapyrusrtPackage.TOP_CAPSULE__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.TOP_CAPSULE__CAPSULEPART:
			getCapsulepart().clear();
			getCapsulepart().addAll((Collection<? extends CapsulePart>) newValue);
			return;
		case PapyrusrtPackage.TOP_CAPSULE__PORTS:
			getPorts().clear();
			getPorts().addAll((Collection<? extends SelectPort>) newValue);
			return;
		case PapyrusrtPackage.TOP_CAPSULE__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.TOP_CAPSULE__CAPSULEPART:
			getCapsulepart().clear();
			return;
		case PapyrusrtPackage.TOP_CAPSULE__PORTS:
			getPorts().clear();
			return;
		case PapyrusrtPackage.TOP_CAPSULE__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.TOP_CAPSULE__CAPSULEPART:
			return capsulepart != null && !capsulepart.isEmpty();
		case PapyrusrtPackage.TOP_CAPSULE__PORTS:
			return ports != null && !ports.isEmpty();
		case PapyrusrtPackage.TOP_CAPSULE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //TopCapsuleImpl
