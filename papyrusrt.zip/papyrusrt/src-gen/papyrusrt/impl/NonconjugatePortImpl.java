/**
 */
package papyrusrt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import papyrusrt.ConjugatePort;
import papyrusrt.NonconjugatePort;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.Protocol;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Nonconjugate Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.NonconjugatePortImpl#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link papyrusrt.impl.NonconjugatePortImpl#getConjugateport <em>Conjugateport</em>}</li>
 *   <li>{@link papyrusrt.impl.NonconjugatePortImpl#getNonConjName <em>Non Conj Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class NonconjugatePortImpl extends SelectPortImpl implements NonconjugatePort {
	/**
	 * The cached value of the '{@link #getProtocol() <em>Protocol</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocol()
	 * @generated
	 * @ordered
	 */
	protected Protocol protocol;

	/**
	 * The cached value of the '{@link #getConjugateport() <em>Conjugateport</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConjugateport()
	 * @generated
	 * @ordered
	 */
	protected ConjugatePort conjugateport;

	/**
	 * The default value of the '{@link #getNonConjName() <em>Non Conj Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNonConjName()
	 * @generated
	 * @ordered
	 */
	protected static final String NON_CONJ_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNonConjName() <em>Non Conj Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNonConjName()
	 * @generated
	 * @ordered
	 */
	protected String nonConjName = NON_CONJ_NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NonconjugatePortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.NONCONJUGATE_PORT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Protocol getProtocol() {
		if (protocol != null && protocol.eIsProxy()) {
			InternalEObject oldProtocol = (InternalEObject) protocol;
			protocol = (Protocol) eResolveProxy(oldProtocol);
			if (protocol != oldProtocol) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							PapyrusrtPackage.NONCONJUGATE_PORT__PROTOCOL, oldProtocol, protocol));
			}
		}
		return protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Protocol basicGetProtocol() {
		return protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProtocol(Protocol newProtocol) {
		Protocol oldProtocol = protocol;
		protocol = newProtocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.NONCONJUGATE_PORT__PROTOCOL,
					oldProtocol, protocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConjugatePort getConjugateport() {
		if (conjugateport != null && conjugateport.eIsProxy()) {
			InternalEObject oldConjugateport = (InternalEObject) conjugateport;
			conjugateport = (ConjugatePort) eResolveProxy(oldConjugateport);
			if (conjugateport != oldConjugateport) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT, oldConjugateport, conjugateport));
			}
		}
		return conjugateport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ConjugatePort basicGetConjugateport() {
		return conjugateport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetConjugateport(ConjugatePort newConjugateport, NotificationChain msgs) {
		ConjugatePort oldConjugateport = conjugateport;
		conjugateport = newConjugateport;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT, oldConjugateport, newConjugateport);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConjugateport(ConjugatePort newConjugateport) {
		if (newConjugateport != conjugateport) {
			NotificationChain msgs = null;
			if (conjugateport != null)
				msgs = ((InternalEObject) conjugateport).eInverseRemove(this,
						PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT, ConjugatePort.class, msgs);
			if (newConjugateport != null)
				msgs = ((InternalEObject) newConjugateport).eInverseAdd(this,
						PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT, ConjugatePort.class, msgs);
			msgs = basicSetConjugateport(newConjugateport, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT,
					newConjugateport, newConjugateport));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNonConjName() {
		return nonConjName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNonConjName(String newNonConjName) {
		String oldNonConjName = nonConjName;
		nonConjName = newNonConjName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.NONCONJUGATE_PORT__NON_CONJ_NAME,
					oldNonConjName, nonConjName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT:
			if (conjugateport != null)
				msgs = ((InternalEObject) conjugateport).eInverseRemove(this,
						PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT, ConjugatePort.class, msgs);
			return basicSetConjugateport((ConjugatePort) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT:
			return basicSetConjugateport(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.NONCONJUGATE_PORT__PROTOCOL:
			if (resolve)
				return getProtocol();
			return basicGetProtocol();
		case PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT:
			if (resolve)
				return getConjugateport();
			return basicGetConjugateport();
		case PapyrusrtPackage.NONCONJUGATE_PORT__NON_CONJ_NAME:
			return getNonConjName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.NONCONJUGATE_PORT__PROTOCOL:
			setProtocol((Protocol) newValue);
			return;
		case PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT:
			setConjugateport((ConjugatePort) newValue);
			return;
		case PapyrusrtPackage.NONCONJUGATE_PORT__NON_CONJ_NAME:
			setNonConjName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.NONCONJUGATE_PORT__PROTOCOL:
			setProtocol((Protocol) null);
			return;
		case PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT:
			setConjugateport((ConjugatePort) null);
			return;
		case PapyrusrtPackage.NONCONJUGATE_PORT__NON_CONJ_NAME:
			setNonConjName(NON_CONJ_NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.NONCONJUGATE_PORT__PROTOCOL:
			return protocol != null;
		case PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT:
			return conjugateport != null;
		case PapyrusrtPackage.NONCONJUGATE_PORT__NON_CONJ_NAME:
			return NON_CONJ_NAME_EDEFAULT == null ? nonConjName != null : !NON_CONJ_NAME_EDEFAULT.equals(nonConjName);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (NonConjName: ");
		result.append(nonConjName);
		result.append(')');
		return result.toString();
	}

} //NonconjugatePortImpl
