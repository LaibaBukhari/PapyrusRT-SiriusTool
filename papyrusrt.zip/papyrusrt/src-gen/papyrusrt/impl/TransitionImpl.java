/**
 */
package papyrusrt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import papyrusrt.Choice;
import papyrusrt.DeepHistory;
import papyrusrt.Junction;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.State;
import papyrusrt.Transition;
import papyrusrt.Trigger;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transition</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.TransitionImpl#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.impl.TransitionImpl#getCodeBlocks <em>Code Blocks</em>}</li>
 *   <li>{@link papyrusrt.impl.TransitionImpl#getTrigger <em>Trigger</em>}</li>
 *   <li>{@link papyrusrt.impl.TransitionImpl#getState <em>State</em>}</li>
 *   <li>{@link papyrusrt.impl.TransitionImpl#getChoice <em>Choice</em>}</li>
 *   <li>{@link papyrusrt.impl.TransitionImpl#getDeephistory <em>Deephistory</em>}</li>
 *   <li>{@link papyrusrt.impl.TransitionImpl#getJunction <em>Junction</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TransitionImpl extends MinimalEObjectImpl.Container implements Transition {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getCodeBlocks() <em>Code Blocks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodeBlocks()
	 * @generated
	 * @ordered
	 */
	protected static final String CODE_BLOCKS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCodeBlocks() <em>Code Blocks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCodeBlocks()
	 * @generated
	 * @ordered
	 */
	protected String codeBlocks = CODE_BLOCKS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTrigger() <em>Trigger</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrigger()
	 * @generated
	 * @ordered
	 */
	protected Trigger trigger;

	/**
	 * The cached value of the '{@link #getState() <em>State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState()
	 * @generated
	 * @ordered
	 */
	protected State state;

	/**
	 * The cached value of the '{@link #getChoice() <em>Choice</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChoice()
	 * @generated
	 * @ordered
	 */
	protected Choice choice;

	/**
	 * The cached value of the '{@link #getDeephistory() <em>Deephistory</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeephistory()
	 * @generated
	 * @ordered
	 */
	protected DeepHistory deephistory;

	/**
	 * The cached value of the '{@link #getJunction() <em>Junction</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJunction()
	 * @generated
	 * @ordered
	 */
	protected Junction junction;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransitionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.TRANSITION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TRANSITION__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCodeBlocks() {
		return codeBlocks;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCodeBlocks(String newCodeBlocks) {
		String oldCodeBlocks = codeBlocks;
		codeBlocks = newCodeBlocks;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TRANSITION__CODE_BLOCKS,
					oldCodeBlocks, codeBlocks));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trigger getTrigger() {
		return trigger;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTrigger(Trigger newTrigger, NotificationChain msgs) {
		Trigger oldTrigger = trigger;
		trigger = newTrigger;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PapyrusrtPackage.TRANSITION__TRIGGER, oldTrigger, newTrigger);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrigger(Trigger newTrigger) {
		if (newTrigger != trigger) {
			NotificationChain msgs = null;
			if (trigger != null)
				msgs = ((InternalEObject) trigger).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PapyrusrtPackage.TRANSITION__TRIGGER, null, msgs);
			if (newTrigger != null)
				msgs = ((InternalEObject) newTrigger).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PapyrusrtPackage.TRANSITION__TRIGGER, null, msgs);
			msgs = basicSetTrigger(newTrigger, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TRANSITION__TRIGGER, newTrigger,
					newTrigger));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State getState() {
		if (state != null && state.eIsProxy()) {
			InternalEObject oldState = (InternalEObject) state;
			state = (State) eResolveProxy(oldState);
			if (state != oldState) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PapyrusrtPackage.TRANSITION__STATE,
							oldState, state));
			}
		}
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public State basicGetState() {
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setState(State newState) {
		State oldState = state;
		state = newState;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TRANSITION__STATE, oldState, state));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Choice getChoice() {
		if (choice != null && choice.eIsProxy()) {
			InternalEObject oldChoice = (InternalEObject) choice;
			choice = (Choice) eResolveProxy(oldChoice);
			if (choice != oldChoice) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PapyrusrtPackage.TRANSITION__CHOICE,
							oldChoice, choice));
			}
		}
		return choice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Choice basicGetChoice() {
		return choice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setChoice(Choice newChoice) {
		Choice oldChoice = choice;
		choice = newChoice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TRANSITION__CHOICE, oldChoice,
					choice));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeepHistory getDeephistory() {
		if (deephistory != null && deephistory.eIsProxy()) {
			InternalEObject oldDeephistory = (InternalEObject) deephistory;
			deephistory = (DeepHistory) eResolveProxy(oldDeephistory);
			if (deephistory != oldDeephistory) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PapyrusrtPackage.TRANSITION__DEEPHISTORY,
							oldDeephistory, deephistory));
			}
		}
		return deephistory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DeepHistory basicGetDeephistory() {
		return deephistory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeephistory(DeepHistory newDeephistory) {
		DeepHistory oldDeephistory = deephistory;
		deephistory = newDeephistory;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TRANSITION__DEEPHISTORY,
					oldDeephistory, deephistory));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Junction getJunction() {
		if (junction != null && junction.eIsProxy()) {
			InternalEObject oldJunction = (InternalEObject) junction;
			junction = (Junction) eResolveProxy(oldJunction);
			if (junction != oldJunction) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PapyrusrtPackage.TRANSITION__JUNCTION,
							oldJunction, junction));
			}
		}
		return junction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Junction basicGetJunction() {
		return junction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setJunction(Junction newJunction) {
		Junction oldJunction = junction;
		junction = newJunction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TRANSITION__JUNCTION, oldJunction,
					junction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.TRANSITION__TRIGGER:
			return basicSetTrigger(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.TRANSITION__NAME:
			return getName();
		case PapyrusrtPackage.TRANSITION__CODE_BLOCKS:
			return getCodeBlocks();
		case PapyrusrtPackage.TRANSITION__TRIGGER:
			return getTrigger();
		case PapyrusrtPackage.TRANSITION__STATE:
			if (resolve)
				return getState();
			return basicGetState();
		case PapyrusrtPackage.TRANSITION__CHOICE:
			if (resolve)
				return getChoice();
			return basicGetChoice();
		case PapyrusrtPackage.TRANSITION__DEEPHISTORY:
			if (resolve)
				return getDeephistory();
			return basicGetDeephistory();
		case PapyrusrtPackage.TRANSITION__JUNCTION:
			if (resolve)
				return getJunction();
			return basicGetJunction();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.TRANSITION__NAME:
			setName((String) newValue);
			return;
		case PapyrusrtPackage.TRANSITION__CODE_BLOCKS:
			setCodeBlocks((String) newValue);
			return;
		case PapyrusrtPackage.TRANSITION__TRIGGER:
			setTrigger((Trigger) newValue);
			return;
		case PapyrusrtPackage.TRANSITION__STATE:
			setState((State) newValue);
			return;
		case PapyrusrtPackage.TRANSITION__CHOICE:
			setChoice((Choice) newValue);
			return;
		case PapyrusrtPackage.TRANSITION__DEEPHISTORY:
			setDeephistory((DeepHistory) newValue);
			return;
		case PapyrusrtPackage.TRANSITION__JUNCTION:
			setJunction((Junction) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.TRANSITION__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PapyrusrtPackage.TRANSITION__CODE_BLOCKS:
			setCodeBlocks(CODE_BLOCKS_EDEFAULT);
			return;
		case PapyrusrtPackage.TRANSITION__TRIGGER:
			setTrigger((Trigger) null);
			return;
		case PapyrusrtPackage.TRANSITION__STATE:
			setState((State) null);
			return;
		case PapyrusrtPackage.TRANSITION__CHOICE:
			setChoice((Choice) null);
			return;
		case PapyrusrtPackage.TRANSITION__DEEPHISTORY:
			setDeephistory((DeepHistory) null);
			return;
		case PapyrusrtPackage.TRANSITION__JUNCTION:
			setJunction((Junction) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.TRANSITION__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PapyrusrtPackage.TRANSITION__CODE_BLOCKS:
			return CODE_BLOCKS_EDEFAULT == null ? codeBlocks != null : !CODE_BLOCKS_EDEFAULT.equals(codeBlocks);
		case PapyrusrtPackage.TRANSITION__TRIGGER:
			return trigger != null;
		case PapyrusrtPackage.TRANSITION__STATE:
			return state != null;
		case PapyrusrtPackage.TRANSITION__CHOICE:
			return choice != null;
		case PapyrusrtPackage.TRANSITION__DEEPHISTORY:
			return deephistory != null;
		case PapyrusrtPackage.TRANSITION__JUNCTION:
			return junction != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", CodeBlocks: ");
		result.append(codeBlocks);
		result.append(')');
		return result.toString();
	}

} //TransitionImpl
