/**
 */
package papyrusrt.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import papyrusrt.ConjugatePort;
import papyrusrt.NonconjugatePort;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.Protocol;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Conjugate Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.ConjugatePortImpl#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link papyrusrt.impl.ConjugatePortImpl#getNonconjugateport <em>Nonconjugateport</em>}</li>
 *   <li>{@link papyrusrt.impl.ConjugatePortImpl#getConjName <em>Conj Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ConjugatePortImpl extends SelectPortImpl implements ConjugatePort {
	/**
	 * The cached value of the '{@link #getProtocol() <em>Protocol</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProtocol()
	 * @generated
	 * @ordered
	 */
	protected Protocol protocol;

	/**
	 * The cached value of the '{@link #getNonconjugateport() <em>Nonconjugateport</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNonconjugateport()
	 * @generated
	 * @ordered
	 */
	protected NonconjugatePort nonconjugateport;

	/**
	 * The default value of the '{@link #getConjName() <em>Conj Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConjName()
	 * @generated
	 * @ordered
	 */
	protected static final String CONJ_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getConjName() <em>Conj Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConjName()
	 * @generated
	 * @ordered
	 */
	protected String conjName = CONJ_NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConjugatePortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.CONJUGATE_PORT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Protocol getProtocol() {
		if (protocol != null && protocol.eIsProxy()) {
			InternalEObject oldProtocol = (InternalEObject) protocol;
			protocol = (Protocol) eResolveProxy(oldProtocol);
			if (protocol != oldProtocol) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, PapyrusrtPackage.CONJUGATE_PORT__PROTOCOL,
							oldProtocol, protocol));
			}
		}
		return protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Protocol basicGetProtocol() {
		return protocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setProtocol(Protocol newProtocol) {
		Protocol oldProtocol = protocol;
		protocol = newProtocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.CONJUGATE_PORT__PROTOCOL,
					oldProtocol, protocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NonconjugatePort getNonconjugateport() {
		if (nonconjugateport != null && nonconjugateport.eIsProxy()) {
			InternalEObject oldNonconjugateport = (InternalEObject) nonconjugateport;
			nonconjugateport = (NonconjugatePort) eResolveProxy(oldNonconjugateport);
			if (nonconjugateport != oldNonconjugateport) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT, oldNonconjugateport, nonconjugateport));
			}
		}
		return nonconjugateport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NonconjugatePort basicGetNonconjugateport() {
		return nonconjugateport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetNonconjugateport(NonconjugatePort newNonconjugateport, NotificationChain msgs) {
		NonconjugatePort oldNonconjugateport = nonconjugateport;
		nonconjugateport = newNonconjugateport;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT, oldNonconjugateport, newNonconjugateport);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNonconjugateport(NonconjugatePort newNonconjugateport) {
		if (newNonconjugateport != nonconjugateport) {
			NotificationChain msgs = null;
			if (nonconjugateport != null)
				msgs = ((InternalEObject) nonconjugateport).eInverseRemove(this,
						PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT, NonconjugatePort.class, msgs);
			if (newNonconjugateport != null)
				msgs = ((InternalEObject) newNonconjugateport).eInverseAdd(this,
						PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT, NonconjugatePort.class, msgs);
			msgs = basicSetNonconjugateport(newNonconjugateport, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT,
					newNonconjugateport, newNonconjugateport));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getConjName() {
		return conjName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConjName(String newConjName) {
		String oldConjName = conjName;
		conjName = newConjName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.CONJUGATE_PORT__CONJ_NAME,
					oldConjName, conjName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT:
			if (nonconjugateport != null)
				msgs = ((InternalEObject) nonconjugateport).eInverseRemove(this,
						PapyrusrtPackage.NONCONJUGATE_PORT__CONJUGATEPORT, NonconjugatePort.class, msgs);
			return basicSetNonconjugateport((NonconjugatePort) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT:
			return basicSetNonconjugateport(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.CONJUGATE_PORT__PROTOCOL:
			if (resolve)
				return getProtocol();
			return basicGetProtocol();
		case PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT:
			if (resolve)
				return getNonconjugateport();
			return basicGetNonconjugateport();
		case PapyrusrtPackage.CONJUGATE_PORT__CONJ_NAME:
			return getConjName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.CONJUGATE_PORT__PROTOCOL:
			setProtocol((Protocol) newValue);
			return;
		case PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT:
			setNonconjugateport((NonconjugatePort) newValue);
			return;
		case PapyrusrtPackage.CONJUGATE_PORT__CONJ_NAME:
			setConjName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.CONJUGATE_PORT__PROTOCOL:
			setProtocol((Protocol) null);
			return;
		case PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT:
			setNonconjugateport((NonconjugatePort) null);
			return;
		case PapyrusrtPackage.CONJUGATE_PORT__CONJ_NAME:
			setConjName(CONJ_NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.CONJUGATE_PORT__PROTOCOL:
			return protocol != null;
		case PapyrusrtPackage.CONJUGATE_PORT__NONCONJUGATEPORT:
			return nonconjugateport != null;
		case PapyrusrtPackage.CONJUGATE_PORT__CONJ_NAME:
			return CONJ_NAME_EDEFAULT == null ? conjName != null : !CONJ_NAME_EDEFAULT.equals(conjName);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (ConjName: ");
		result.append(conjName);
		result.append(')');
		return result.toString();
	}

} //ConjugatePortImpl
