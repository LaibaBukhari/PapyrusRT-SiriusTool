/**
 */
package papyrusrt.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import papyrusrt.FramePort;
import papyrusrt.PapyrusrtPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Frame Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.FramePortImpl#getFrameName <em>Frame Name</em>}</li>
 *   <li>{@link papyrusrt.impl.FramePortImpl#getSystemProtocol <em>System Protocol</em>}</li>
 * </ul>
 *
 * @generated
 */
public class FramePortImpl extends SelectPortImpl implements FramePort {
	/**
	 * The default value of the '{@link #getFrameName() <em>Frame Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFrameName()
	 * @generated
	 * @ordered
	 */
	protected static final String FRAME_NAME_EDEFAULT = "Frame";

	/**
	 * The cached value of the '{@link #getFrameName() <em>Frame Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFrameName()
	 * @generated
	 * @ordered
	 */
	protected String frameName = FRAME_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSystemProtocol() <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSystemProtocol()
	 * @generated
	 * @ordered
	 */
	protected static final String SYSTEM_PROTOCOL_EDEFAULT = "Frame";

	/**
	 * The cached value of the '{@link #getSystemProtocol() <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSystemProtocol()
	 * @generated
	 * @ordered
	 */
	protected String systemProtocol = SYSTEM_PROTOCOL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FramePortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.FRAME_PORT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFrameName() {
		return frameName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFrameName(String newFrameName) {
		String oldFrameName = frameName;
		frameName = newFrameName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.FRAME_PORT__FRAME_NAME, oldFrameName,
					frameName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSystemProtocol() {
		return systemProtocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSystemProtocol(String newSystemProtocol) {
		String oldSystemProtocol = systemProtocol;
		systemProtocol = newSystemProtocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.FRAME_PORT__SYSTEM_PROTOCOL,
					oldSystemProtocol, systemProtocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.FRAME_PORT__FRAME_NAME:
			return getFrameName();
		case PapyrusrtPackage.FRAME_PORT__SYSTEM_PROTOCOL:
			return getSystemProtocol();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.FRAME_PORT__FRAME_NAME:
			setFrameName((String) newValue);
			return;
		case PapyrusrtPackage.FRAME_PORT__SYSTEM_PROTOCOL:
			setSystemProtocol((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.FRAME_PORT__FRAME_NAME:
			setFrameName(FRAME_NAME_EDEFAULT);
			return;
		case PapyrusrtPackage.FRAME_PORT__SYSTEM_PROTOCOL:
			setSystemProtocol(SYSTEM_PROTOCOL_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.FRAME_PORT__FRAME_NAME:
			return FRAME_NAME_EDEFAULT == null ? frameName != null : !FRAME_NAME_EDEFAULT.equals(frameName);
		case PapyrusrtPackage.FRAME_PORT__SYSTEM_PROTOCOL:
			return SYSTEM_PROTOCOL_EDEFAULT == null ? systemProtocol != null
					: !SYSTEM_PROTOCOL_EDEFAULT.equals(systemProtocol);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (FrameName: ");
		result.append(frameName);
		result.append(", SystemProtocol: ");
		result.append(systemProtocol);
		result.append(')');
		return result.toString();
	}

} //FramePortImpl
