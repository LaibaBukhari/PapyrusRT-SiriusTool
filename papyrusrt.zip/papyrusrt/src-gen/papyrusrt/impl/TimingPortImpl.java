/**
 */
package papyrusrt.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import papyrusrt.PapyrusrtPackage;
import papyrusrt.TimingPort;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Timing Port</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.TimingPortImpl#getTimingName <em>Timing Name</em>}</li>
 *   <li>{@link papyrusrt.impl.TimingPortImpl#getSystemProtocol <em>System Protocol</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TimingPortImpl extends SelectPortImpl implements TimingPort {
	/**
	 * The default value of the '{@link #getTimingName() <em>Timing Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimingName()
	 * @generated
	 * @ordered
	 */
	protected static final String TIMING_NAME_EDEFAULT = "Timer";

	/**
	 * The cached value of the '{@link #getTimingName() <em>Timing Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTimingName()
	 * @generated
	 * @ordered
	 */
	protected String timingName = TIMING_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getSystemProtocol() <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSystemProtocol()
	 * @generated
	 * @ordered
	 */
	protected static final String SYSTEM_PROTOCOL_EDEFAULT = "In timeout()";

	/**
	 * The cached value of the '{@link #getSystemProtocol() <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSystemProtocol()
	 * @generated
	 * @ordered
	 */
	protected String systemProtocol = SYSTEM_PROTOCOL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TimingPortImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.TIMING_PORT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTimingName() {
		return timingName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTimingName(String newTimingName) {
		String oldTimingName = timingName;
		timingName = newTimingName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TIMING_PORT__TIMING_NAME,
					oldTimingName, timingName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSystemProtocol() {
		return systemProtocol;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSystemProtocol(String newSystemProtocol) {
		String oldSystemProtocol = systemProtocol;
		systemProtocol = newSystemProtocol;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.TIMING_PORT__SYSTEM_PROTOCOL,
					oldSystemProtocol, systemProtocol));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.TIMING_PORT__TIMING_NAME:
			return getTimingName();
		case PapyrusrtPackage.TIMING_PORT__SYSTEM_PROTOCOL:
			return getSystemProtocol();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.TIMING_PORT__TIMING_NAME:
			setTimingName((String) newValue);
			return;
		case PapyrusrtPackage.TIMING_PORT__SYSTEM_PROTOCOL:
			setSystemProtocol((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.TIMING_PORT__TIMING_NAME:
			setTimingName(TIMING_NAME_EDEFAULT);
			return;
		case PapyrusrtPackage.TIMING_PORT__SYSTEM_PROTOCOL:
			setSystemProtocol(SYSTEM_PROTOCOL_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.TIMING_PORT__TIMING_NAME:
			return TIMING_NAME_EDEFAULT == null ? timingName != null : !TIMING_NAME_EDEFAULT.equals(timingName);
		case PapyrusrtPackage.TIMING_PORT__SYSTEM_PROTOCOL:
			return SYSTEM_PROTOCOL_EDEFAULT == null ? systemProtocol != null
					: !SYSTEM_PROTOCOL_EDEFAULT.equals(systemProtocol);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (TimingName: ");
		result.append(timingName);
		result.append(", SystemProtocol: ");
		result.append(systemProtocol);
		result.append(')');
		return result.toString();
	}

} //TimingPortImpl
