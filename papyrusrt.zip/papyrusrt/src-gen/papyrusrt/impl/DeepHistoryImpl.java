/**
 */
package papyrusrt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

import papyrusrt.DeepHistory;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.Trans;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Deep History</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.DeepHistoryImpl#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.impl.DeepHistoryImpl#getHistoryType <em>History Type</em>}</li>
 *   <li>{@link papyrusrt.impl.DeepHistoryImpl#getAction <em>Action</em>}</li>
 *   <li>{@link papyrusrt.impl.DeepHistoryImpl#getTrans <em>Trans</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DeepHistoryImpl extends MinimalEObjectImpl.Container implements DeepHistory {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getHistoryType() <em>History Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHistoryType()
	 * @generated
	 * @ordered
	 */
	protected static final String HISTORY_TYPE_EDEFAULT = "DeepHistory";

	/**
	 * The cached value of the '{@link #getHistoryType() <em>History Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHistoryType()
	 * @generated
	 * @ordered
	 */
	protected String historyType = HISTORY_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAction() <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction()
	 * @generated
	 * @ordered
	 */
	protected static final String ACTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAction() <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction()
	 * @generated
	 * @ordered
	 */
	protected String action = ACTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTrans() <em>Trans</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrans()
	 * @generated
	 * @ordered
	 */
	protected EList<Trans> trans;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DeepHistoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.DEEP_HISTORY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.DEEP_HISTORY__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHistoryType() {
		return historyType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHistoryType(String newHistoryType) {
		String oldHistoryType = historyType;
		historyType = newHistoryType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.DEEP_HISTORY__HISTORY_TYPE,
					oldHistoryType, historyType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAction() {
		return action;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAction(String newAction) {
		String oldAction = action;
		action = newAction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.DEEP_HISTORY__ACTION, oldAction,
					action));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Trans> getTrans() {
		if (trans == null) {
			trans = new EObjectResolvingEList<Trans>(Trans.class, this, PapyrusrtPackage.DEEP_HISTORY__TRANS);
		}
		return trans;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.DEEP_HISTORY__NAME:
			return getName();
		case PapyrusrtPackage.DEEP_HISTORY__HISTORY_TYPE:
			return getHistoryType();
		case PapyrusrtPackage.DEEP_HISTORY__ACTION:
			return getAction();
		case PapyrusrtPackage.DEEP_HISTORY__TRANS:
			return getTrans();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.DEEP_HISTORY__NAME:
			setName((String) newValue);
			return;
		case PapyrusrtPackage.DEEP_HISTORY__HISTORY_TYPE:
			setHistoryType((String) newValue);
			return;
		case PapyrusrtPackage.DEEP_HISTORY__ACTION:
			setAction((String) newValue);
			return;
		case PapyrusrtPackage.DEEP_HISTORY__TRANS:
			getTrans().clear();
			getTrans().addAll((Collection<? extends Trans>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.DEEP_HISTORY__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PapyrusrtPackage.DEEP_HISTORY__HISTORY_TYPE:
			setHistoryType(HISTORY_TYPE_EDEFAULT);
			return;
		case PapyrusrtPackage.DEEP_HISTORY__ACTION:
			setAction(ACTION_EDEFAULT);
			return;
		case PapyrusrtPackage.DEEP_HISTORY__TRANS:
			getTrans().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.DEEP_HISTORY__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PapyrusrtPackage.DEEP_HISTORY__HISTORY_TYPE:
			return HISTORY_TYPE_EDEFAULT == null ? historyType != null : !HISTORY_TYPE_EDEFAULT.equals(historyType);
		case PapyrusrtPackage.DEEP_HISTORY__ACTION:
			return ACTION_EDEFAULT == null ? action != null : !ACTION_EDEFAULT.equals(action);
		case PapyrusrtPackage.DEEP_HISTORY__TRANS:
			return trans != null && !trans.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", HistoryType: ");
		result.append(historyType);
		result.append(", Action: ");
		result.append(action);
		result.append(')');
		return result.toString();
	}

} //DeepHistoryImpl
