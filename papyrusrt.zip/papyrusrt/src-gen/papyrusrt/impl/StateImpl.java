/**
 */
package papyrusrt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import papyrusrt.EntryPoint;
import papyrusrt.ExitPoint;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.State;
import papyrusrt.Transition;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.StateImpl#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.impl.StateImpl#getEntryAction <em>Entry Action</em>}</li>
 *   <li>{@link papyrusrt.impl.StateImpl#getExitAction <em>Exit Action</em>}</li>
 *   <li>{@link papyrusrt.impl.StateImpl#getInternalTransition <em>Internal Transition</em>}</li>
 *   <li>{@link papyrusrt.impl.StateImpl#getEntrypoint <em>Entrypoint</em>}</li>
 *   <li>{@link papyrusrt.impl.StateImpl#getExitpoint <em>Exitpoint</em>}</li>
 *   <li>{@link papyrusrt.impl.StateImpl#getTransition <em>Transition</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StateImpl extends MinimalEObjectImpl.Container implements State {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getEntryAction() <em>Entry Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntryAction()
	 * @generated
	 * @ordered
	 */
	protected static final String ENTRY_ACTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEntryAction() <em>Entry Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntryAction()
	 * @generated
	 * @ordered
	 */
	protected String entryAction = ENTRY_ACTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getExitAction() <em>Exit Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExitAction()
	 * @generated
	 * @ordered
	 */
	protected static final String EXIT_ACTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getExitAction() <em>Exit Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExitAction()
	 * @generated
	 * @ordered
	 */
	protected String exitAction = EXIT_ACTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getInternalTransition() <em>Internal Transition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInternalTransition()
	 * @generated
	 * @ordered
	 */
	protected static final String INTERNAL_TRANSITION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInternalTransition() <em>Internal Transition</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInternalTransition()
	 * @generated
	 * @ordered
	 */
	protected String internalTransition = INTERNAL_TRANSITION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getEntrypoint() <em>Entrypoint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntrypoint()
	 * @generated
	 * @ordered
	 */
	protected EList<EntryPoint> entrypoint;

	/**
	 * The cached value of the '{@link #getExitpoint() <em>Exitpoint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExitpoint()
	 * @generated
	 * @ordered
	 */
	protected EList<ExitPoint> exitpoint;

	/**
	 * The cached value of the '{@link #getTransition() <em>Transition</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransition()
	 * @generated
	 * @ordered
	 */
	protected EList<Transition> transition;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.STATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.STATE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEntryAction() {
		return entryAction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEntryAction(String newEntryAction) {
		String oldEntryAction = entryAction;
		entryAction = newEntryAction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.STATE__ENTRY_ACTION, oldEntryAction,
					entryAction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getExitAction() {
		return exitAction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExitAction(String newExitAction) {
		String oldExitAction = exitAction;
		exitAction = newExitAction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.STATE__EXIT_ACTION, oldExitAction,
					exitAction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getInternalTransition() {
		return internalTransition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInternalTransition(String newInternalTransition) {
		String oldInternalTransition = internalTransition;
		internalTransition = newInternalTransition;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.STATE__INTERNAL_TRANSITION,
					oldInternalTransition, internalTransition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EntryPoint> getEntrypoint() {
		if (entrypoint == null) {
			entrypoint = new EObjectContainmentEList<EntryPoint>(EntryPoint.class, this,
					PapyrusrtPackage.STATE__ENTRYPOINT);
		}
		return entrypoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ExitPoint> getExitpoint() {
		if (exitpoint == null) {
			exitpoint = new EObjectContainmentEList<ExitPoint>(ExitPoint.class, this,
					PapyrusrtPackage.STATE__EXITPOINT);
		}
		return exitpoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Transition> getTransition() {
		if (transition == null) {
			transition = new EObjectResolvingEList<Transition>(Transition.class, this,
					PapyrusrtPackage.STATE__TRANSITION);
		}
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.STATE__ENTRYPOINT:
			return ((InternalEList<?>) getEntrypoint()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.STATE__EXITPOINT:
			return ((InternalEList<?>) getExitpoint()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.STATE__NAME:
			return getName();
		case PapyrusrtPackage.STATE__ENTRY_ACTION:
			return getEntryAction();
		case PapyrusrtPackage.STATE__EXIT_ACTION:
			return getExitAction();
		case PapyrusrtPackage.STATE__INTERNAL_TRANSITION:
			return getInternalTransition();
		case PapyrusrtPackage.STATE__ENTRYPOINT:
			return getEntrypoint();
		case PapyrusrtPackage.STATE__EXITPOINT:
			return getExitpoint();
		case PapyrusrtPackage.STATE__TRANSITION:
			return getTransition();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.STATE__NAME:
			setName((String) newValue);
			return;
		case PapyrusrtPackage.STATE__ENTRY_ACTION:
			setEntryAction((String) newValue);
			return;
		case PapyrusrtPackage.STATE__EXIT_ACTION:
			setExitAction((String) newValue);
			return;
		case PapyrusrtPackage.STATE__INTERNAL_TRANSITION:
			setInternalTransition((String) newValue);
			return;
		case PapyrusrtPackage.STATE__ENTRYPOINT:
			getEntrypoint().clear();
			getEntrypoint().addAll((Collection<? extends EntryPoint>) newValue);
			return;
		case PapyrusrtPackage.STATE__EXITPOINT:
			getExitpoint().clear();
			getExitpoint().addAll((Collection<? extends ExitPoint>) newValue);
			return;
		case PapyrusrtPackage.STATE__TRANSITION:
			getTransition().clear();
			getTransition().addAll((Collection<? extends Transition>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.STATE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PapyrusrtPackage.STATE__ENTRY_ACTION:
			setEntryAction(ENTRY_ACTION_EDEFAULT);
			return;
		case PapyrusrtPackage.STATE__EXIT_ACTION:
			setExitAction(EXIT_ACTION_EDEFAULT);
			return;
		case PapyrusrtPackage.STATE__INTERNAL_TRANSITION:
			setInternalTransition(INTERNAL_TRANSITION_EDEFAULT);
			return;
		case PapyrusrtPackage.STATE__ENTRYPOINT:
			getEntrypoint().clear();
			return;
		case PapyrusrtPackage.STATE__EXITPOINT:
			getExitpoint().clear();
			return;
		case PapyrusrtPackage.STATE__TRANSITION:
			getTransition().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.STATE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PapyrusrtPackage.STATE__ENTRY_ACTION:
			return ENTRY_ACTION_EDEFAULT == null ? entryAction != null : !ENTRY_ACTION_EDEFAULT.equals(entryAction);
		case PapyrusrtPackage.STATE__EXIT_ACTION:
			return EXIT_ACTION_EDEFAULT == null ? exitAction != null : !EXIT_ACTION_EDEFAULT.equals(exitAction);
		case PapyrusrtPackage.STATE__INTERNAL_TRANSITION:
			return INTERNAL_TRANSITION_EDEFAULT == null ? internalTransition != null
					: !INTERNAL_TRANSITION_EDEFAULT.equals(internalTransition);
		case PapyrusrtPackage.STATE__ENTRYPOINT:
			return entrypoint != null && !entrypoint.isEmpty();
		case PapyrusrtPackage.STATE__EXITPOINT:
			return exitpoint != null && !exitpoint.isEmpty();
		case PapyrusrtPackage.STATE__TRANSITION:
			return transition != null && !transition.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", EntryAction: ");
		result.append(entryAction);
		result.append(", ExitAction: ");
		result.append(exitAction);
		result.append(", InternalTransition: ");
		result.append(internalTransition);
		result.append(')');
		return result.toString();
	}

} //StateImpl
