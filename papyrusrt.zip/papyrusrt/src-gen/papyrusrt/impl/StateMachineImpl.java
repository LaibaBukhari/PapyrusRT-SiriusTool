/**
 */
package papyrusrt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import papyrusrt.Choice;
import papyrusrt.DeepHistory;
import papyrusrt.EntryPoint;
import papyrusrt.ExitPoint;
import papyrusrt.InitialState;
import papyrusrt.Junction;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.State;
import papyrusrt.StateMachine;
import papyrusrt.Trans;
import papyrusrt.Transition;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State Machine</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getRegion <em>Region</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getInitialstate <em>Initialstate</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getState <em>State</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getTransition <em>Transition</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getChoice <em>Choice</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getDeephistory <em>Deephistory</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getJunction <em>Junction</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getTrans <em>Trans</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getExitpoint <em>Exitpoint</em>}</li>
 *   <li>{@link papyrusrt.impl.StateMachineImpl#getEntrypoint <em>Entrypoint</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StateMachineImpl extends MinimalEObjectImpl.Container implements StateMachine {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = "";

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getRegion() <em>Region</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRegion()
	 * @generated
	 * @ordered
	 */
	protected static final String REGION_EDEFAULT = "Region1";

	/**
	 * The cached value of the '{@link #getRegion() <em>Region</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRegion()
	 * @generated
	 * @ordered
	 */
	protected String region = REGION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getInitialstate() <em>Initialstate</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInitialstate()
	 * @generated
	 * @ordered
	 */
	protected InitialState initialstate;

	/**
	 * The cached value of the '{@link #getState() <em>State</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getState()
	 * @generated
	 * @ordered
	 */
	protected EList<State> state;

	/**
	 * The cached value of the '{@link #getTransition() <em>Transition</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransition()
	 * @generated
	 * @ordered
	 */
	protected EList<Transition> transition;

	/**
	 * The cached value of the '{@link #getChoice() <em>Choice</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChoice()
	 * @generated
	 * @ordered
	 */
	protected EList<Choice> choice;

	/**
	 * The cached value of the '{@link #getDeephistory() <em>Deephistory</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeephistory()
	 * @generated
	 * @ordered
	 */
	protected EList<DeepHistory> deephistory;

	/**
	 * The cached value of the '{@link #getJunction() <em>Junction</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getJunction()
	 * @generated
	 * @ordered
	 */
	protected EList<Junction> junction;

	/**
	 * The cached value of the '{@link #getTrans() <em>Trans</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrans()
	 * @generated
	 * @ordered
	 */
	protected EList<Trans> trans;

	/**
	 * The cached value of the '{@link #getExitpoint() <em>Exitpoint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExitpoint()
	 * @generated
	 * @ordered
	 */
	protected EList<ExitPoint> exitpoint;

	/**
	 * The cached value of the '{@link #getEntrypoint() <em>Entrypoint</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntrypoint()
	 * @generated
	 * @ordered
	 */
	protected EList<EntryPoint> entrypoint;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StateMachineImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.STATE_MACHINE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.STATE_MACHINE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRegion(String newRegion) {
		String oldRegion = region;
		region = newRegion;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.STATE_MACHINE__REGION, oldRegion,
					region));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InitialState getInitialstate() {
		return initialstate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetInitialstate(InitialState newInitialstate, NotificationChain msgs) {
		InitialState oldInitialstate = initialstate;
		initialstate = newInitialstate;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					PapyrusrtPackage.STATE_MACHINE__INITIALSTATE, oldInitialstate, newInitialstate);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setInitialstate(InitialState newInitialstate) {
		if (newInitialstate != initialstate) {
			NotificationChain msgs = null;
			if (initialstate != null)
				msgs = ((InternalEObject) initialstate).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - PapyrusrtPackage.STATE_MACHINE__INITIALSTATE, null, msgs);
			if (newInitialstate != null)
				msgs = ((InternalEObject) newInitialstate).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - PapyrusrtPackage.STATE_MACHINE__INITIALSTATE, null, msgs);
			msgs = basicSetInitialstate(newInitialstate, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.STATE_MACHINE__INITIALSTATE,
					newInitialstate, newInitialstate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<State> getState() {
		if (state == null) {
			state = new EObjectContainmentEList<State>(State.class, this, PapyrusrtPackage.STATE_MACHINE__STATE);
		}
		return state;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Transition> getTransition() {
		if (transition == null) {
			transition = new EObjectContainmentEList<Transition>(Transition.class, this,
					PapyrusrtPackage.STATE_MACHINE__TRANSITION);
		}
		return transition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Choice> getChoice() {
		if (choice == null) {
			choice = new EObjectContainmentEList<Choice>(Choice.class, this, PapyrusrtPackage.STATE_MACHINE__CHOICE);
		}
		return choice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<DeepHistory> getDeephistory() {
		if (deephistory == null) {
			deephistory = new EObjectContainmentEList<DeepHistory>(DeepHistory.class, this,
					PapyrusrtPackage.STATE_MACHINE__DEEPHISTORY);
		}
		return deephistory;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Junction> getJunction() {
		if (junction == null) {
			junction = new EObjectContainmentEList<Junction>(Junction.class, this,
					PapyrusrtPackage.STATE_MACHINE__JUNCTION);
		}
		return junction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Trans> getTrans() {
		if (trans == null) {
			trans = new EObjectContainmentEList<Trans>(Trans.class, this, PapyrusrtPackage.STATE_MACHINE__TRANS);
		}
		return trans;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ExitPoint> getExitpoint() {
		if (exitpoint == null) {
			exitpoint = new EObjectContainmentEList<ExitPoint>(ExitPoint.class, this,
					PapyrusrtPackage.STATE_MACHINE__EXITPOINT);
		}
		return exitpoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EntryPoint> getEntrypoint() {
		if (entrypoint == null) {
			entrypoint = new EObjectContainmentEList<EntryPoint>(EntryPoint.class, this,
					PapyrusrtPackage.STATE_MACHINE__ENTRYPOINT);
		}
		return entrypoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.STATE_MACHINE__INITIALSTATE:
			return basicSetInitialstate(null, msgs);
		case PapyrusrtPackage.STATE_MACHINE__STATE:
			return ((InternalEList<?>) getState()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.STATE_MACHINE__TRANSITION:
			return ((InternalEList<?>) getTransition()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.STATE_MACHINE__CHOICE:
			return ((InternalEList<?>) getChoice()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.STATE_MACHINE__DEEPHISTORY:
			return ((InternalEList<?>) getDeephistory()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.STATE_MACHINE__JUNCTION:
			return ((InternalEList<?>) getJunction()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.STATE_MACHINE__TRANS:
			return ((InternalEList<?>) getTrans()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.STATE_MACHINE__EXITPOINT:
			return ((InternalEList<?>) getExitpoint()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.STATE_MACHINE__ENTRYPOINT:
			return ((InternalEList<?>) getEntrypoint()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.STATE_MACHINE__NAME:
			return getName();
		case PapyrusrtPackage.STATE_MACHINE__REGION:
			return getRegion();
		case PapyrusrtPackage.STATE_MACHINE__INITIALSTATE:
			return getInitialstate();
		case PapyrusrtPackage.STATE_MACHINE__STATE:
			return getState();
		case PapyrusrtPackage.STATE_MACHINE__TRANSITION:
			return getTransition();
		case PapyrusrtPackage.STATE_MACHINE__CHOICE:
			return getChoice();
		case PapyrusrtPackage.STATE_MACHINE__DEEPHISTORY:
			return getDeephistory();
		case PapyrusrtPackage.STATE_MACHINE__JUNCTION:
			return getJunction();
		case PapyrusrtPackage.STATE_MACHINE__TRANS:
			return getTrans();
		case PapyrusrtPackage.STATE_MACHINE__EXITPOINT:
			return getExitpoint();
		case PapyrusrtPackage.STATE_MACHINE__ENTRYPOINT:
			return getEntrypoint();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.STATE_MACHINE__NAME:
			setName((String) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__REGION:
			setRegion((String) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__INITIALSTATE:
			setInitialstate((InitialState) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__STATE:
			getState().clear();
			getState().addAll((Collection<? extends State>) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__TRANSITION:
			getTransition().clear();
			getTransition().addAll((Collection<? extends Transition>) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__CHOICE:
			getChoice().clear();
			getChoice().addAll((Collection<? extends Choice>) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__DEEPHISTORY:
			getDeephistory().clear();
			getDeephistory().addAll((Collection<? extends DeepHistory>) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__JUNCTION:
			getJunction().clear();
			getJunction().addAll((Collection<? extends Junction>) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__TRANS:
			getTrans().clear();
			getTrans().addAll((Collection<? extends Trans>) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__EXITPOINT:
			getExitpoint().clear();
			getExitpoint().addAll((Collection<? extends ExitPoint>) newValue);
			return;
		case PapyrusrtPackage.STATE_MACHINE__ENTRYPOINT:
			getEntrypoint().clear();
			getEntrypoint().addAll((Collection<? extends EntryPoint>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.STATE_MACHINE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case PapyrusrtPackage.STATE_MACHINE__REGION:
			setRegion(REGION_EDEFAULT);
			return;
		case PapyrusrtPackage.STATE_MACHINE__INITIALSTATE:
			setInitialstate((InitialState) null);
			return;
		case PapyrusrtPackage.STATE_MACHINE__STATE:
			getState().clear();
			return;
		case PapyrusrtPackage.STATE_MACHINE__TRANSITION:
			getTransition().clear();
			return;
		case PapyrusrtPackage.STATE_MACHINE__CHOICE:
			getChoice().clear();
			return;
		case PapyrusrtPackage.STATE_MACHINE__DEEPHISTORY:
			getDeephistory().clear();
			return;
		case PapyrusrtPackage.STATE_MACHINE__JUNCTION:
			getJunction().clear();
			return;
		case PapyrusrtPackage.STATE_MACHINE__TRANS:
			getTrans().clear();
			return;
		case PapyrusrtPackage.STATE_MACHINE__EXITPOINT:
			getExitpoint().clear();
			return;
		case PapyrusrtPackage.STATE_MACHINE__ENTRYPOINT:
			getEntrypoint().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.STATE_MACHINE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case PapyrusrtPackage.STATE_MACHINE__REGION:
			return REGION_EDEFAULT == null ? region != null : !REGION_EDEFAULT.equals(region);
		case PapyrusrtPackage.STATE_MACHINE__INITIALSTATE:
			return initialstate != null;
		case PapyrusrtPackage.STATE_MACHINE__STATE:
			return state != null && !state.isEmpty();
		case PapyrusrtPackage.STATE_MACHINE__TRANSITION:
			return transition != null && !transition.isEmpty();
		case PapyrusrtPackage.STATE_MACHINE__CHOICE:
			return choice != null && !choice.isEmpty();
		case PapyrusrtPackage.STATE_MACHINE__DEEPHISTORY:
			return deephistory != null && !deephistory.isEmpty();
		case PapyrusrtPackage.STATE_MACHINE__JUNCTION:
			return junction != null && !junction.isEmpty();
		case PapyrusrtPackage.STATE_MACHINE__TRANS:
			return trans != null && !trans.isEmpty();
		case PapyrusrtPackage.STATE_MACHINE__EXITPOINT:
			return exitpoint != null && !exitpoint.isEmpty();
		case PapyrusrtPackage.STATE_MACHINE__ENTRYPOINT:
			return entrypoint != null && !entrypoint.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(", Region: ");
		result.append(region);
		result.append(')');
		return result.toString();
	}

} //StateMachineImpl
