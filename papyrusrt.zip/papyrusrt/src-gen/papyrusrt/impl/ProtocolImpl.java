/**
 */
package papyrusrt.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import papyrusrt.Inmessage;
import papyrusrt.Inoutmessage;
import papyrusrt.Outmessage;
import papyrusrt.PapyrusrtPackage;
import papyrusrt.Protocol;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Protocol</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.impl.ProtocolImpl#getOutmessage <em>Outmessage</em>}</li>
 *   <li>{@link papyrusrt.impl.ProtocolImpl#getInmessage <em>Inmessage</em>}</li>
 *   <li>{@link papyrusrt.impl.ProtocolImpl#getInoutmessage <em>Inoutmessage</em>}</li>
 *   <li>{@link papyrusrt.impl.ProtocolImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ProtocolImpl extends MinimalEObjectImpl.Container implements Protocol {
	/**
	 * The cached value of the '{@link #getOutmessage() <em>Outmessage</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Outmessage> outmessage;

	/**
	 * The cached value of the '{@link #getInmessage() <em>Inmessage</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Inmessage> inmessage;

	/**
	 * The cached value of the '{@link #getInoutmessage() <em>Inoutmessage</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInoutmessage()
	 * @generated
	 * @ordered
	 */
	protected EList<Inoutmessage> inoutmessage;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProtocolImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PapyrusrtPackage.Literals.PROTOCOL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Outmessage> getOutmessage() {
		if (outmessage == null) {
			outmessage = new EObjectContainmentEList<Outmessage>(Outmessage.class, this,
					PapyrusrtPackage.PROTOCOL__OUTMESSAGE);
		}
		return outmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Inmessage> getInmessage() {
		if (inmessage == null) {
			inmessage = new EObjectContainmentEList<Inmessage>(Inmessage.class, this,
					PapyrusrtPackage.PROTOCOL__INMESSAGE);
		}
		return inmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Inoutmessage> getInoutmessage() {
		if (inoutmessage == null) {
			inoutmessage = new EObjectContainmentEList<Inoutmessage>(Inoutmessage.class, this,
					PapyrusrtPackage.PROTOCOL__INOUTMESSAGE);
		}
		return inoutmessage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, PapyrusrtPackage.PROTOCOL__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case PapyrusrtPackage.PROTOCOL__OUTMESSAGE:
			return ((InternalEList<?>) getOutmessage()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PROTOCOL__INMESSAGE:
			return ((InternalEList<?>) getInmessage()).basicRemove(otherEnd, msgs);
		case PapyrusrtPackage.PROTOCOL__INOUTMESSAGE:
			return ((InternalEList<?>) getInoutmessage()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case PapyrusrtPackage.PROTOCOL__OUTMESSAGE:
			return getOutmessage();
		case PapyrusrtPackage.PROTOCOL__INMESSAGE:
			return getInmessage();
		case PapyrusrtPackage.PROTOCOL__INOUTMESSAGE:
			return getInoutmessage();
		case PapyrusrtPackage.PROTOCOL__NAME:
			return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case PapyrusrtPackage.PROTOCOL__OUTMESSAGE:
			getOutmessage().clear();
			getOutmessage().addAll((Collection<? extends Outmessage>) newValue);
			return;
		case PapyrusrtPackage.PROTOCOL__INMESSAGE:
			getInmessage().clear();
			getInmessage().addAll((Collection<? extends Inmessage>) newValue);
			return;
		case PapyrusrtPackage.PROTOCOL__INOUTMESSAGE:
			getInoutmessage().clear();
			getInoutmessage().addAll((Collection<? extends Inoutmessage>) newValue);
			return;
		case PapyrusrtPackage.PROTOCOL__NAME:
			setName((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.PROTOCOL__OUTMESSAGE:
			getOutmessage().clear();
			return;
		case PapyrusrtPackage.PROTOCOL__INMESSAGE:
			getInmessage().clear();
			return;
		case PapyrusrtPackage.PROTOCOL__INOUTMESSAGE:
			getInoutmessage().clear();
			return;
		case PapyrusrtPackage.PROTOCOL__NAME:
			setName(NAME_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case PapyrusrtPackage.PROTOCOL__OUTMESSAGE:
			return outmessage != null && !outmessage.isEmpty();
		case PapyrusrtPackage.PROTOCOL__INMESSAGE:
			return inmessage != null && !inmessage.isEmpty();
		case PapyrusrtPackage.PROTOCOL__INOUTMESSAGE:
			return inoutmessage != null && !inoutmessage.isEmpty();
		case PapyrusrtPackage.PROTOCOL__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (Name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //ProtocolImpl
