/**
 */
package papyrusrt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Transition</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.Transition#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.Transition#getCodeBlocks <em>Code Blocks</em>}</li>
 *   <li>{@link papyrusrt.Transition#getTrigger <em>Trigger</em>}</li>
 *   <li>{@link papyrusrt.Transition#getState <em>State</em>}</li>
 *   <li>{@link papyrusrt.Transition#getChoice <em>Choice</em>}</li>
 *   <li>{@link papyrusrt.Transition#getDeephistory <em>Deephistory</em>}</li>
 *   <li>{@link papyrusrt.Transition#getJunction <em>Junction</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getTransition()
 * @model
 * @generated
 */
public interface Transition extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see papyrusrt.PapyrusrtPackage#getTransition_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link papyrusrt.Transition#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Code Blocks</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Code Blocks</em>' attribute.
	 * @see #setCodeBlocks(String)
	 * @see papyrusrt.PapyrusrtPackage#getTransition_CodeBlocks()
	 * @model
	 * @generated
	 */
	String getCodeBlocks();

	/**
	 * Sets the value of the '{@link papyrusrt.Transition#getCodeBlocks <em>Code Blocks</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Code Blocks</em>' attribute.
	 * @see #getCodeBlocks()
	 * @generated
	 */
	void setCodeBlocks(String value);

	/**
	 * Returns the value of the '<em><b>Trigger</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trigger</em>' containment reference.
	 * @see #setTrigger(Trigger)
	 * @see papyrusrt.PapyrusrtPackage#getTransition_Trigger()
	 * @model containment="true"
	 * @generated
	 */
	Trigger getTrigger();

	/**
	 * Sets the value of the '{@link papyrusrt.Transition#getTrigger <em>Trigger</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trigger</em>' containment reference.
	 * @see #getTrigger()
	 * @generated
	 */
	void setTrigger(Trigger value);

	/**
	 * Returns the value of the '<em><b>State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' reference.
	 * @see #setState(State)
	 * @see papyrusrt.PapyrusrtPackage#getTransition_State()
	 * @model
	 * @generated
	 */
	State getState();

	/**
	 * Sets the value of the '{@link papyrusrt.Transition#getState <em>State</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>State</em>' reference.
	 * @see #getState()
	 * @generated
	 */
	void setState(State value);

	/**
	 * Returns the value of the '<em><b>Choice</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Choice</em>' reference.
	 * @see #setChoice(Choice)
	 * @see papyrusrt.PapyrusrtPackage#getTransition_Choice()
	 * @model
	 * @generated
	 */
	Choice getChoice();

	/**
	 * Sets the value of the '{@link papyrusrt.Transition#getChoice <em>Choice</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Choice</em>' reference.
	 * @see #getChoice()
	 * @generated
	 */
	void setChoice(Choice value);

	/**
	 * Returns the value of the '<em><b>Deephistory</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Deephistory</em>' reference.
	 * @see #setDeephistory(DeepHistory)
	 * @see papyrusrt.PapyrusrtPackage#getTransition_Deephistory()
	 * @model
	 * @generated
	 */
	DeepHistory getDeephistory();

	/**
	 * Sets the value of the '{@link papyrusrt.Transition#getDeephistory <em>Deephistory</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Deephistory</em>' reference.
	 * @see #getDeephistory()
	 * @generated
	 */
	void setDeephistory(DeepHistory value);

	/**
	 * Returns the value of the '<em><b>Junction</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Junction</em>' reference.
	 * @see #setJunction(Junction)
	 * @see papyrusrt.PapyrusrtPackage#getTransition_Junction()
	 * @model
	 * @generated
	 */
	Junction getJunction();

	/**
	 * Sets the value of the '{@link papyrusrt.Transition#getJunction <em>Junction</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Junction</em>' reference.
	 * @see #getJunction()
	 * @generated
	 */
	void setJunction(Junction value);

} // Transition
