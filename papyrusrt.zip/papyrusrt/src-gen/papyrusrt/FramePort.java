/**
 */
package papyrusrt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Frame Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.FramePort#getFrameName <em>Frame Name</em>}</li>
 *   <li>{@link papyrusrt.FramePort#getSystemProtocol <em>System Protocol</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getFramePort()
 * @model
 * @generated
 */
public interface FramePort extends SelectPort {
	/**
	 * Returns the value of the '<em><b>Frame Name</b></em>' attribute.
	 * The default value is <code>"Frame"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Frame Name</em>' attribute.
	 * @see #setFrameName(String)
	 * @see papyrusrt.PapyrusrtPackage#getFramePort_FrameName()
	 * @model default="Frame"
	 * @generated
	 */
	String getFrameName();

	/**
	 * Sets the value of the '{@link papyrusrt.FramePort#getFrameName <em>Frame Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Frame Name</em>' attribute.
	 * @see #getFrameName()
	 * @generated
	 */
	void setFrameName(String value);

	/**
	 * Returns the value of the '<em><b>System Protocol</b></em>' attribute.
	 * The default value is <code>"Frame"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>System Protocol</em>' attribute.
	 * @see #setSystemProtocol(String)
	 * @see papyrusrt.PapyrusrtPackage#getFramePort_SystemProtocol()
	 * @model default="Frame"
	 * @generated
	 */
	String getSystemProtocol();

	/**
	 * Sets the value of the '{@link papyrusrt.FramePort#getSystemProtocol <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>System Protocol</em>' attribute.
	 * @see #getSystemProtocol()
	 * @generated
	 */
	void setSystemProtocol(String value);

} // FramePort
