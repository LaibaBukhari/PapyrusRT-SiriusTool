/**
 */
package papyrusrt.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import papyrusrt.*;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see papyrusrt.PapyrusrtPackage
 * @generated
 */
public class PapyrusrtAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static PapyrusrtPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PapyrusrtAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = PapyrusrtPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PapyrusrtSwitch<Adapter> modelSwitch = new PapyrusrtSwitch<Adapter>() {
		@Override
		public Adapter caseTopCapsule(TopCapsule object) {
			return createTopCapsuleAdapter();
		}

		@Override
		public Adapter caseCapsulePart(CapsulePart object) {
			return createCapsulePartAdapter();
		}

		@Override
		public Adapter caseSelectPort(SelectPort object) {
			return createSelectPortAdapter();
		}

		@Override
		public Adapter caseProtocol(Protocol object) {
			return createProtocolAdapter();
		}

		@Override
		public Adapter caseOutmessage(Outmessage object) {
			return createOutmessageAdapter();
		}

		@Override
		public Adapter caseInmessage(Inmessage object) {
			return createInmessageAdapter();
		}

		@Override
		public Adapter caseInoutmessage(Inoutmessage object) {
			return createInoutmessageAdapter();
		}

		@Override
		public Adapter caseConjugatePort(ConjugatePort object) {
			return createConjugatePortAdapter();
		}

		@Override
		public Adapter caseNonconjugatePort(NonconjugatePort object) {
			return createNonconjugatePortAdapter();
		}

		@Override
		public Adapter caseFramePort(FramePort object) {
			return createFramePortAdapter();
		}

		@Override
		public Adapter caseLogPort(LogPort object) {
			return createLogPortAdapter();
		}

		@Override
		public Adapter caseTimingPort(TimingPort object) {
			return createTimingPortAdapter();
		}

		@Override
		public Adapter caseStateMachine(StateMachine object) {
			return createStateMachineAdapter();
		}

		@Override
		public Adapter caseState(State object) {
			return createStateAdapter();
		}

		@Override
		public Adapter caseEntryPoint(EntryPoint object) {
			return createEntryPointAdapter();
		}

		@Override
		public Adapter caseExitPoint(ExitPoint object) {
			return createExitPointAdapter();
		}

		@Override
		public Adapter caseInitialState(InitialState object) {
			return createInitialStateAdapter();
		}

		@Override
		public Adapter caseTransition(Transition object) {
			return createTransitionAdapter();
		}

		@Override
		public Adapter caseChoice(Choice object) {
			return createChoiceAdapter();
		}

		@Override
		public Adapter caseDeepHistory(DeepHistory object) {
			return createDeepHistoryAdapter();
		}

		@Override
		public Adapter caseJunction(Junction object) {
			return createJunctionAdapter();
		}

		@Override
		public Adapter caseTrigger(Trigger object) {
			return createTriggerAdapter();
		}

		@Override
		public Adapter caseTrans(Trans object) {
			return createTransAdapter();
		}

		@Override
		public Adapter casePapyrusRTModel(PapyrusRTModel object) {
			return createPapyrusRTModelAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.TopCapsule <em>Top Capsule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.TopCapsule
	 * @generated
	 */
	public Adapter createTopCapsuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.CapsulePart <em>Capsule Part</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.CapsulePart
	 * @generated
	 */
	public Adapter createCapsulePartAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.SelectPort <em>Select Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.SelectPort
	 * @generated
	 */
	public Adapter createSelectPortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Protocol <em>Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Protocol
	 * @generated
	 */
	public Adapter createProtocolAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Outmessage <em>Outmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Outmessage
	 * @generated
	 */
	public Adapter createOutmessageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Inmessage <em>Inmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Inmessage
	 * @generated
	 */
	public Adapter createInmessageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Inoutmessage <em>Inoutmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Inoutmessage
	 * @generated
	 */
	public Adapter createInoutmessageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.ConjugatePort <em>Conjugate Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.ConjugatePort
	 * @generated
	 */
	public Adapter createConjugatePortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.NonconjugatePort <em>Nonconjugate Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.NonconjugatePort
	 * @generated
	 */
	public Adapter createNonconjugatePortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.FramePort <em>Frame Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.FramePort
	 * @generated
	 */
	public Adapter createFramePortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.LogPort <em>Log Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.LogPort
	 * @generated
	 */
	public Adapter createLogPortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.TimingPort <em>Timing Port</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.TimingPort
	 * @generated
	 */
	public Adapter createTimingPortAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.StateMachine <em>State Machine</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.StateMachine
	 * @generated
	 */
	public Adapter createStateMachineAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.State <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.State
	 * @generated
	 */
	public Adapter createStateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.EntryPoint <em>Entry Point</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.EntryPoint
	 * @generated
	 */
	public Adapter createEntryPointAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.ExitPoint <em>Exit Point</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.ExitPoint
	 * @generated
	 */
	public Adapter createExitPointAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.InitialState <em>Initial State</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.InitialState
	 * @generated
	 */
	public Adapter createInitialStateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Transition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Transition
	 * @generated
	 */
	public Adapter createTransitionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Choice <em>Choice</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Choice
	 * @generated
	 */
	public Adapter createChoiceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.DeepHistory <em>Deep History</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.DeepHistory
	 * @generated
	 */
	public Adapter createDeepHistoryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Junction <em>Junction</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Junction
	 * @generated
	 */
	public Adapter createJunctionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Trigger <em>Trigger</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Trigger
	 * @generated
	 */
	public Adapter createTriggerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.Trans <em>Trans</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.Trans
	 * @generated
	 */
	public Adapter createTransAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link papyrusrt.PapyrusRTModel <em>Papyrus RT Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see papyrusrt.PapyrusRTModel
	 * @generated
	 */
	public Adapter createPapyrusRTModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //PapyrusrtAdapterFactory
