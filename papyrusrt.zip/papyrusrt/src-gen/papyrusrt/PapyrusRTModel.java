/**
 */
package papyrusrt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Papyrus RT Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.PapyrusRTModel#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getTopcapsule <em>Topcapsule</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getStatemachine <em>Statemachine</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getCapsulepart <em>Capsulepart</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getInitialstate <em>Initialstate</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getState <em>State</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getEntrypoint <em>Entrypoint</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getExitpoint <em>Exitpoint</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getTransition <em>Transition</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getTrigger <em>Trigger</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getJunction <em>Junction</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getDeephistory <em>Deephistory</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getTrans <em>Trans</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getOutmessage <em>Outmessage</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getInoutmessage <em>Inoutmessage</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getInmessage <em>Inmessage</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getChoice <em>Choice</em>}</li>
 *   <li>{@link papyrusrt.PapyrusRTModel#getPort <em>Port</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel()
 * @model
 * @generated
 */
public interface PapyrusRTModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Protocol</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Protocol}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protocol</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Protocol()
	 * @model containment="true"
	 * @generated
	 */
	EList<Protocol> getProtocol();

	/**
	 * Returns the value of the '<em><b>Topcapsule</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.TopCapsule}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Topcapsule</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Topcapsule()
	 * @model containment="true"
	 * @generated
	 */
	EList<TopCapsule> getTopcapsule();

	/**
	 * Returns the value of the '<em><b>Statemachine</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.StateMachine}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Statemachine</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Statemachine()
	 * @model containment="true"
	 * @generated
	 */
	EList<StateMachine> getStatemachine();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link papyrusrt.PapyrusRTModel#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Capsulepart</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.CapsulePart}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Capsulepart</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Capsulepart()
	 * @model containment="true"
	 * @generated
	 */
	EList<CapsulePart> getCapsulepart();

	/**
	 * Returns the value of the '<em><b>Initialstate</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.InitialState}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Initialstate</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Initialstate()
	 * @model containment="true"
	 * @generated
	 */
	EList<InitialState> getInitialstate();

	/**
	 * Returns the value of the '<em><b>State</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.State}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>State</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_State()
	 * @model containment="true"
	 * @generated
	 */
	EList<State> getState();

	/**
	 * Returns the value of the '<em><b>Entrypoint</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.EntryPoint}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entrypoint</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Entrypoint()
	 * @model containment="true"
	 * @generated
	 */
	EList<EntryPoint> getEntrypoint();

	/**
	 * Returns the value of the '<em><b>Exitpoint</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.ExitPoint}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Exitpoint</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Exitpoint()
	 * @model containment="true"
	 * @generated
	 */
	EList<ExitPoint> getExitpoint();

	/**
	 * Returns the value of the '<em><b>Transition</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Transition}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Transition</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Transition()
	 * @model containment="true"
	 * @generated
	 */
	EList<Transition> getTransition();

	/**
	 * Returns the value of the '<em><b>Trigger</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Trigger}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trigger</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Trigger()
	 * @model containment="true"
	 * @generated
	 */
	EList<Trigger> getTrigger();

	/**
	 * Returns the value of the '<em><b>Junction</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Junction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Junction</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Junction()
	 * @model containment="true"
	 * @generated
	 */
	EList<Junction> getJunction();

	/**
	 * Returns the value of the '<em><b>Deephistory</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.DeepHistory}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Deephistory</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Deephistory()
	 * @model containment="true"
	 * @generated
	 */
	EList<DeepHistory> getDeephistory();

	/**
	 * Returns the value of the '<em><b>Trans</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Trans}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trans</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Trans()
	 * @model containment="true"
	 * @generated
	 */
	EList<Trans> getTrans();

	/**
	 * Returns the value of the '<em><b>Outmessage</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Outmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outmessage</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Outmessage()
	 * @model containment="true"
	 * @generated
	 */
	EList<Outmessage> getOutmessage();

	/**
	 * Returns the value of the '<em><b>Inoutmessage</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Inoutmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inoutmessage</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Inoutmessage()
	 * @model containment="true"
	 * @generated
	 */
	EList<Inoutmessage> getInoutmessage();

	/**
	 * Returns the value of the '<em><b>Inmessage</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Inmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inmessage</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Inmessage()
	 * @model containment="true"
	 * @generated
	 */
	EList<Inmessage> getInmessage();

	/**
	 * Returns the value of the '<em><b>Choice</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Choice}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Choice</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Choice()
	 * @model containment="true"
	 * @generated
	 */
	EList<Choice> getChoice();

	/**
	 * Returns the value of the '<em><b>Port</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.SelectPort}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Port</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getPapyrusRTModel_Port()
	 * @model containment="true"
	 * @generated
	 */
	EList<SelectPort> getPort();

} // PapyrusRTModel
