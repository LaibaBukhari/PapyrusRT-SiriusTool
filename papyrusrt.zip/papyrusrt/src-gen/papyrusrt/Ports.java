/**
 */
package papyrusrt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ports</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see papyrusrt.PapyrusrtPackage#getPorts()
 * @model
 * @generated
 */
public interface Ports extends EObject {
} // Ports
