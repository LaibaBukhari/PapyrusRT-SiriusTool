/**
 */
package papyrusrt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trigger</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.Trigger#getPorts <em>Ports</em>}</li>
 *   <li>{@link papyrusrt.Trigger#getOutmessage <em>Outmessage</em>}</li>
 *   <li>{@link papyrusrt.Trigger#getInoutmessage <em>Inoutmessage</em>}</li>
 *   <li>{@link papyrusrt.Trigger#getInmessage <em>Inmessage</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getTrigger()
 * @model
 * @generated
 */
public interface Trigger extends EObject {
	/**
	 * Returns the value of the '<em><b>Ports</b></em>' reference list.
	 * The list contents are of type {@link papyrusrt.SelectPort}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ports</em>' reference list.
	 * @see papyrusrt.PapyrusrtPackage#getTrigger_Ports()
	 * @model
	 * @generated
	 */
	EList<SelectPort> getPorts();

	/**
	 * Returns the value of the '<em><b>Outmessage</b></em>' reference list.
	 * The list contents are of type {@link papyrusrt.Outmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outmessage</em>' reference list.
	 * @see papyrusrt.PapyrusrtPackage#getTrigger_Outmessage()
	 * @model
	 * @generated
	 */
	EList<Outmessage> getOutmessage();

	/**
	 * Returns the value of the '<em><b>Inoutmessage</b></em>' reference list.
	 * The list contents are of type {@link papyrusrt.Inoutmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inoutmessage</em>' reference list.
	 * @see papyrusrt.PapyrusrtPackage#getTrigger_Inoutmessage()
	 * @model
	 * @generated
	 */
	EList<Inoutmessage> getInoutmessage();

	/**
	 * Returns the value of the '<em><b>Inmessage</b></em>' reference list.
	 * The list contents are of type {@link papyrusrt.Inmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inmessage</em>' reference list.
	 * @see papyrusrt.PapyrusrtPackage#getTrigger_Inmessage()
	 * @model
	 * @generated
	 */
	EList<Inmessage> getInmessage();

} // Trigger
