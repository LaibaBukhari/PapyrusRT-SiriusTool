/**
 */
package papyrusrt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conjugate Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.ConjugatePort#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link papyrusrt.ConjugatePort#getNonconjugateport <em>Nonconjugateport</em>}</li>
 *   <li>{@link papyrusrt.ConjugatePort#getConjName <em>Conj Name</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getConjugatePort()
 * @model
 * @generated
 */
public interface ConjugatePort extends SelectPort {
	/**
	 * Returns the value of the '<em><b>Protocol</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protocol</em>' reference.
	 * @see #setProtocol(Protocol)
	 * @see papyrusrt.PapyrusrtPackage#getConjugatePort_Protocol()
	 * @model
	 * @generated
	 */
	Protocol getProtocol();

	/**
	 * Sets the value of the '{@link papyrusrt.ConjugatePort#getProtocol <em>Protocol</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Protocol</em>' reference.
	 * @see #getProtocol()
	 * @generated
	 */
	void setProtocol(Protocol value);

	/**
	 * Returns the value of the '<em><b>Nonconjugateport</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link papyrusrt.NonconjugatePort#getConjugateport <em>Conjugateport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nonconjugateport</em>' reference.
	 * @see #setNonconjugateport(NonconjugatePort)
	 * @see papyrusrt.PapyrusrtPackage#getConjugatePort_Nonconjugateport()
	 * @see papyrusrt.NonconjugatePort#getConjugateport
	 * @model opposite="conjugateport"
	 * @generated
	 */
	NonconjugatePort getNonconjugateport();

	/**
	 * Sets the value of the '{@link papyrusrt.ConjugatePort#getNonconjugateport <em>Nonconjugateport</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nonconjugateport</em>' reference.
	 * @see #getNonconjugateport()
	 * @generated
	 */
	void setNonconjugateport(NonconjugatePort value);

	/**
	 * Returns the value of the '<em><b>Conj Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Conj Name</em>' attribute.
	 * @see #setConjName(String)
	 * @see papyrusrt.PapyrusrtPackage#getConjugatePort_ConjName()
	 * @model
	 * @generated
	 */
	String getConjName();

	/**
	 * Sets the value of the '{@link papyrusrt.ConjugatePort#getConjName <em>Conj Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Conj Name</em>' attribute.
	 * @see #getConjName()
	 * @generated
	 */
	void setConjName(String value);

} // ConjugatePort
