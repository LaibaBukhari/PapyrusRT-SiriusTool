/**
 */
package papyrusrt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Deep History</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.DeepHistory#getName <em>Name</em>}</li>
 *   <li>{@link papyrusrt.DeepHistory#getHistoryType <em>History Type</em>}</li>
 *   <li>{@link papyrusrt.DeepHistory#getAction <em>Action</em>}</li>
 *   <li>{@link papyrusrt.DeepHistory#getTrans <em>Trans</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getDeepHistory()
 * @model
 * @generated
 */
public interface DeepHistory extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see papyrusrt.PapyrusrtPackage#getDeepHistory_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link papyrusrt.DeepHistory#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>History Type</b></em>' attribute.
	 * The default value is <code>"DeepHistory"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>History Type</em>' attribute.
	 * @see #setHistoryType(String)
	 * @see papyrusrt.PapyrusrtPackage#getDeepHistory_HistoryType()
	 * @model default="DeepHistory"
	 * @generated
	 */
	String getHistoryType();

	/**
	 * Sets the value of the '{@link papyrusrt.DeepHistory#getHistoryType <em>History Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>History Type</em>' attribute.
	 * @see #getHistoryType()
	 * @generated
	 */
	void setHistoryType(String value);

	/**
	 * Returns the value of the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Action</em>' attribute.
	 * @see #setAction(String)
	 * @see papyrusrt.PapyrusrtPackage#getDeepHistory_Action()
	 * @model
	 * @generated
	 */
	String getAction();

	/**
	 * Sets the value of the '{@link papyrusrt.DeepHistory#getAction <em>Action</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Action</em>' attribute.
	 * @see #getAction()
	 * @generated
	 */
	void setAction(String value);

	/**
	 * Returns the value of the '<em><b>Trans</b></em>' reference list.
	 * The list contents are of type {@link papyrusrt.Trans}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trans</em>' reference list.
	 * @see papyrusrt.PapyrusrtPackage#getDeepHistory_Trans()
	 * @model
	 * @generated
	 */
	EList<Trans> getTrans();

} // DeepHistory
