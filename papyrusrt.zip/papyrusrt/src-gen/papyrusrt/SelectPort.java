/**
 */
package papyrusrt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Select Port</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see papyrusrt.PapyrusrtPackage#getSelectPort()
 * @model
 * @generated
 */
public interface SelectPort extends EObject {
} // SelectPort
