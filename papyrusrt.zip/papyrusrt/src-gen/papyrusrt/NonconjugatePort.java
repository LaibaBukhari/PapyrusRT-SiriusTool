/**
 */
package papyrusrt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Nonconjugate Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.NonconjugatePort#getProtocol <em>Protocol</em>}</li>
 *   <li>{@link papyrusrt.NonconjugatePort#getConjugateport <em>Conjugateport</em>}</li>
 *   <li>{@link papyrusrt.NonconjugatePort#getNonConjName <em>Non Conj Name</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getNonconjugatePort()
 * @model
 * @generated
 */
public interface NonconjugatePort extends SelectPort {
	/**
	 * Returns the value of the '<em><b>Protocol</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Protocol</em>' reference.
	 * @see #setProtocol(Protocol)
	 * @see papyrusrt.PapyrusrtPackage#getNonconjugatePort_Protocol()
	 * @model
	 * @generated
	 */
	Protocol getProtocol();

	/**
	 * Sets the value of the '{@link papyrusrt.NonconjugatePort#getProtocol <em>Protocol</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Protocol</em>' reference.
	 * @see #getProtocol()
	 * @generated
	 */
	void setProtocol(Protocol value);

	/**
	 * Returns the value of the '<em><b>Conjugateport</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link papyrusrt.ConjugatePort#getNonconjugateport <em>Nonconjugateport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Conjugateport</em>' reference.
	 * @see #setConjugateport(ConjugatePort)
	 * @see papyrusrt.PapyrusrtPackage#getNonconjugatePort_Conjugateport()
	 * @see papyrusrt.ConjugatePort#getNonconjugateport
	 * @model opposite="nonconjugateport"
	 * @generated
	 */
	ConjugatePort getConjugateport();

	/**
	 * Sets the value of the '{@link papyrusrt.NonconjugatePort#getConjugateport <em>Conjugateport</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Conjugateport</em>' reference.
	 * @see #getConjugateport()
	 * @generated
	 */
	void setConjugateport(ConjugatePort value);

	/**
	 * Returns the value of the '<em><b>Non Conj Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Non Conj Name</em>' attribute.
	 * @see #setNonConjName(String)
	 * @see papyrusrt.PapyrusrtPackage#getNonconjugatePort_NonConjName()
	 * @model
	 * @generated
	 */
	String getNonConjName();

	/**
	 * Sets the value of the '{@link papyrusrt.NonconjugatePort#getNonConjName <em>Non Conj Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Non Conj Name</em>' attribute.
	 * @see #getNonConjName()
	 * @generated
	 */
	void setNonConjName(String value);

} // NonconjugatePort
