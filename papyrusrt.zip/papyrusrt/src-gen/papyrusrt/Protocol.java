/**
 */
package papyrusrt;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Protocol</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.Protocol#getOutmessage <em>Outmessage</em>}</li>
 *   <li>{@link papyrusrt.Protocol#getInmessage <em>Inmessage</em>}</li>
 *   <li>{@link papyrusrt.Protocol#getInoutmessage <em>Inoutmessage</em>}</li>
 *   <li>{@link papyrusrt.Protocol#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getProtocol()
 * @model
 * @generated
 */
public interface Protocol extends EObject {
	/**
	 * Returns the value of the '<em><b>Outmessage</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Outmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outmessage</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getProtocol_Outmessage()
	 * @model containment="true"
	 * @generated
	 */
	EList<Outmessage> getOutmessage();

	/**
	 * Returns the value of the '<em><b>Inmessage</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Inmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inmessage</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getProtocol_Inmessage()
	 * @model containment="true"
	 * @generated
	 */
	EList<Inmessage> getInmessage();

	/**
	 * Returns the value of the '<em><b>Inoutmessage</b></em>' containment reference list.
	 * The list contents are of type {@link papyrusrt.Inoutmessage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inoutmessage</em>' containment reference list.
	 * @see papyrusrt.PapyrusrtPackage#getProtocol_Inoutmessage()
	 * @model containment="true"
	 * @generated
	 */
	EList<Inoutmessage> getInoutmessage();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see papyrusrt.PapyrusrtPackage#getProtocol_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link papyrusrt.Protocol#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // Protocol
