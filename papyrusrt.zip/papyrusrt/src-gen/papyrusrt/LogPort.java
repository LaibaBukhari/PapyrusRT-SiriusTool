/**
 */
package papyrusrt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Log Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.LogPort#getLogName <em>Log Name</em>}</li>
 *   <li>{@link papyrusrt.LogPort#getSystemProtocol <em>System Protocol</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getLogPort()
 * @model
 * @generated
 */
public interface LogPort extends SelectPort {
	/**
	 * Returns the value of the '<em><b>Log Name</b></em>' attribute.
	 * The default value is <code>"Log"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Log Name</em>' attribute.
	 * @see #setLogName(String)
	 * @see papyrusrt.PapyrusrtPackage#getLogPort_LogName()
	 * @model default="Log"
	 * @generated
	 */
	String getLogName();

	/**
	 * Sets the value of the '{@link papyrusrt.LogPort#getLogName <em>Log Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Log Name</em>' attribute.
	 * @see #getLogName()
	 * @generated
	 */
	void setLogName(String value);

	/**
	 * Returns the value of the '<em><b>System Protocol</b></em>' attribute.
	 * The default value is <code>"Log"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>System Protocol</em>' attribute.
	 * @see #setSystemProtocol(String)
	 * @see papyrusrt.PapyrusrtPackage#getLogPort_SystemProtocol()
	 * @model default="Log"
	 * @generated
	 */
	String getSystemProtocol();

	/**
	 * Sets the value of the '{@link papyrusrt.LogPort#getSystemProtocol <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>System Protocol</em>' attribute.
	 * @see #getSystemProtocol()
	 * @generated
	 */
	void setSystemProtocol(String value);

} // LogPort
