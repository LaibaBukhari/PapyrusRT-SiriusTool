/**
 */
package papyrusrt;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Timing Port</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link papyrusrt.TimingPort#getTimingName <em>Timing Name</em>}</li>
 *   <li>{@link papyrusrt.TimingPort#getSystemProtocol <em>System Protocol</em>}</li>
 * </ul>
 *
 * @see papyrusrt.PapyrusrtPackage#getTimingPort()
 * @model
 * @generated
 */
public interface TimingPort extends SelectPort {
	/**
	 * Returns the value of the '<em><b>Timing Name</b></em>' attribute.
	 * The default value is <code>"Timer"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Timing Name</em>' attribute.
	 * @see #setTimingName(String)
	 * @see papyrusrt.PapyrusrtPackage#getTimingPort_TimingName()
	 * @model default="Timer"
	 * @generated
	 */
	String getTimingName();

	/**
	 * Sets the value of the '{@link papyrusrt.TimingPort#getTimingName <em>Timing Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Timing Name</em>' attribute.
	 * @see #getTimingName()
	 * @generated
	 */
	void setTimingName(String value);

	/**
	 * Returns the value of the '<em><b>System Protocol</b></em>' attribute.
	 * The default value is <code>"In timeout()"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>System Protocol</em>' attribute.
	 * @see #setSystemProtocol(String)
	 * @see papyrusrt.PapyrusrtPackage#getTimingPort_SystemProtocol()
	 * @model default="In timeout()"
	 * @generated
	 */
	String getSystemProtocol();

	/**
	 * Sets the value of the '{@link papyrusrt.TimingPort#getSystemProtocol <em>System Protocol</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>System Protocol</em>' attribute.
	 * @see #getSystemProtocol()
	 * @generated
	 */
	void setSystemProtocol(String value);

} // TimingPort
