/**
 */
package papyrusrt;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PORT</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see papyrusrt.PapyrusrtPackage#getPORT()
 * @model
 * @generated
 */
public interface PORT extends EObject {
} // PORT
