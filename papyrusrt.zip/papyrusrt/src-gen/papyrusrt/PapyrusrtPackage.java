/**
 */
package papyrusrt;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see papyrusrt.PapyrusrtFactory
 * @model kind="package"
 * @generated
 */
public interface PapyrusrtPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "papyrusrt";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/papyrusrt";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "papyrusrt";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	PapyrusrtPackage eINSTANCE = papyrusrt.impl.PapyrusrtPackageImpl.init();

	/**
	 * The meta object id for the '{@link papyrusrt.impl.TopCapsuleImpl <em>Top Capsule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.TopCapsuleImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTopCapsule()
	 * @generated
	 */
	int TOP_CAPSULE = 0;

	/**
	 * The feature id for the '<em><b>Capsulepart</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_CAPSULE__CAPSULEPART = 0;

	/**
	 * The feature id for the '<em><b>Ports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_CAPSULE__PORTS = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_CAPSULE__NAME = 2;

	/**
	 * The number of structural features of the '<em>Top Capsule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_CAPSULE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Top Capsule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TOP_CAPSULE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.CapsulePartImpl <em>Capsule Part</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.CapsulePartImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getCapsulePart()
	 * @generated
	 */
	int CAPSULE_PART = 1;

	/**
	 * The feature id for the '<em><b>Ports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAPSULE_PART__PORTS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAPSULE_PART__NAME = 1;

	/**
	 * The feature id for the '<em><b>Statemachine</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAPSULE_PART__STATEMACHINE = 2;

	/**
	 * The number of structural features of the '<em>Capsule Part</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAPSULE_PART_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Capsule Part</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CAPSULE_PART_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.SelectPortImpl <em>Select Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.SelectPortImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getSelectPort()
	 * @generated
	 */
	int SELECT_PORT = 2;

	/**
	 * The number of structural features of the '<em>Select Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECT_PORT_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Select Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECT_PORT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.ProtocolImpl <em>Protocol</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.ProtocolImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getProtocol()
	 * @generated
	 */
	int PROTOCOL = 3;

	/**
	 * The feature id for the '<em><b>Outmessage</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROTOCOL__OUTMESSAGE = 0;

	/**
	 * The feature id for the '<em><b>Inmessage</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROTOCOL__INMESSAGE = 1;

	/**
	 * The feature id for the '<em><b>Inoutmessage</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROTOCOL__INOUTMESSAGE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROTOCOL__NAME = 3;

	/**
	 * The number of structural features of the '<em>Protocol</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROTOCOL_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Protocol</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROTOCOL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.OutmessageImpl <em>Outmessage</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.OutmessageImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getOutmessage()
	 * @generated
	 */
	int OUTMESSAGE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTMESSAGE__NAME = 0;

	/**
	 * The number of structural features of the '<em>Outmessage</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTMESSAGE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Outmessage</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTMESSAGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.InmessageImpl <em>Inmessage</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.InmessageImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getInmessage()
	 * @generated
	 */
	int INMESSAGE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INMESSAGE__NAME = 0;

	/**
	 * The number of structural features of the '<em>Inmessage</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INMESSAGE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Inmessage</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INMESSAGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.InoutmessageImpl <em>Inoutmessage</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.InoutmessageImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getInoutmessage()
	 * @generated
	 */
	int INOUTMESSAGE = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INOUTMESSAGE__NAME = 0;

	/**
	 * The number of structural features of the '<em>Inoutmessage</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INOUTMESSAGE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Inoutmessage</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INOUTMESSAGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.ConjugatePortImpl <em>Conjugate Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.ConjugatePortImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getConjugatePort()
	 * @generated
	 */
	int CONJUGATE_PORT = 7;

	/**
	 * The feature id for the '<em><b>Protocol</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUGATE_PORT__PROTOCOL = SELECT_PORT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Nonconjugateport</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUGATE_PORT__NONCONJUGATEPORT = SELECT_PORT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Conj Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUGATE_PORT__CONJ_NAME = SELECT_PORT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Conjugate Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUGATE_PORT_FEATURE_COUNT = SELECT_PORT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Conjugate Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONJUGATE_PORT_OPERATION_COUNT = SELECT_PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.NonconjugatePortImpl <em>Nonconjugate Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.NonconjugatePortImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getNonconjugatePort()
	 * @generated
	 */
	int NONCONJUGATE_PORT = 8;

	/**
	 * The feature id for the '<em><b>Protocol</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NONCONJUGATE_PORT__PROTOCOL = SELECT_PORT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Conjugateport</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NONCONJUGATE_PORT__CONJUGATEPORT = SELECT_PORT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Non Conj Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NONCONJUGATE_PORT__NON_CONJ_NAME = SELECT_PORT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Nonconjugate Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NONCONJUGATE_PORT_FEATURE_COUNT = SELECT_PORT_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>Nonconjugate Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NONCONJUGATE_PORT_OPERATION_COUNT = SELECT_PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.FramePortImpl <em>Frame Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.FramePortImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getFramePort()
	 * @generated
	 */
	int FRAME_PORT = 9;

	/**
	 * The feature id for the '<em><b>Frame Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAME_PORT__FRAME_NAME = SELECT_PORT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>System Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAME_PORT__SYSTEM_PROTOCOL = SELECT_PORT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Frame Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAME_PORT_FEATURE_COUNT = SELECT_PORT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Frame Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FRAME_PORT_OPERATION_COUNT = SELECT_PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.LogPortImpl <em>Log Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.LogPortImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getLogPort()
	 * @generated
	 */
	int LOG_PORT = 10;

	/**
	 * The feature id for the '<em><b>Log Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOG_PORT__LOG_NAME = SELECT_PORT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>System Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOG_PORT__SYSTEM_PROTOCOL = SELECT_PORT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Log Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOG_PORT_FEATURE_COUNT = SELECT_PORT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Log Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LOG_PORT_OPERATION_COUNT = SELECT_PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.TimingPortImpl <em>Timing Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.TimingPortImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTimingPort()
	 * @generated
	 */
	int TIMING_PORT = 11;

	/**
	 * The feature id for the '<em><b>Timing Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIMING_PORT__TIMING_NAME = SELECT_PORT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>System Protocol</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIMING_PORT__SYSTEM_PROTOCOL = SELECT_PORT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Timing Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIMING_PORT_FEATURE_COUNT = SELECT_PORT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Timing Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIMING_PORT_OPERATION_COUNT = SELECT_PORT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.StateMachineImpl <em>State Machine</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.StateMachineImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getStateMachine()
	 * @generated
	 */
	int STATE_MACHINE = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Region</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__REGION = 1;

	/**
	 * The feature id for the '<em><b>Initialstate</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__INITIALSTATE = 2;

	/**
	 * The feature id for the '<em><b>State</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__STATE = 3;

	/**
	 * The feature id for the '<em><b>Transition</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__TRANSITION = 4;

	/**
	 * The feature id for the '<em><b>Choice</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__CHOICE = 5;

	/**
	 * The feature id for the '<em><b>Deephistory</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__DEEPHISTORY = 6;

	/**
	 * The feature id for the '<em><b>Junction</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__JUNCTION = 7;

	/**
	 * The feature id for the '<em><b>Trans</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__TRANS = 8;

	/**
	 * The feature id for the '<em><b>Exitpoint</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__EXITPOINT = 9;

	/**
	 * The feature id for the '<em><b>Entrypoint</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE__ENTRYPOINT = 10;

	/**
	 * The number of structural features of the '<em>State Machine</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE_FEATURE_COUNT = 11;

	/**
	 * The number of operations of the '<em>State Machine</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_MACHINE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.StateImpl <em>State</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.StateImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getState()
	 * @generated
	 */
	int STATE = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Entry Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__ENTRY_ACTION = 1;

	/**
	 * The feature id for the '<em><b>Exit Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__EXIT_ACTION = 2;

	/**
	 * The feature id for the '<em><b>Internal Transition</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__INTERNAL_TRANSITION = 3;

	/**
	 * The feature id for the '<em><b>Entrypoint</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__ENTRYPOINT = 4;

	/**
	 * The feature id for the '<em><b>Exitpoint</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__EXITPOINT = 5;

	/**
	 * The feature id for the '<em><b>Transition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE__TRANSITION = 6;

	/**
	 * The number of structural features of the '<em>State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.EntryPointImpl <em>Entry Point</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.EntryPointImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getEntryPoint()
	 * @generated
	 */
	int ENTRY_POINT = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY_POINT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY_POINT__LABEL = 1;

	/**
	 * The feature id for the '<em><b>Kind</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY_POINT__KIND = 2;

	/**
	 * The number of structural features of the '<em>Entry Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY_POINT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Entry Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTRY_POINT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.ExitPointImpl <em>Exit Point</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.ExitPointImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getExitPoint()
	 * @generated
	 */
	int EXIT_POINT = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXIT_POINT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXIT_POINT__LABEL = 1;

	/**
	 * The feature id for the '<em><b>Kind</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXIT_POINT__KIND = 2;

	/**
	 * The number of structural features of the '<em>Exit Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXIT_POINT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Exit Point</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXIT_POINT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.InitialStateImpl <em>Initial State</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.InitialStateImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getInitialState()
	 * @generated
	 */
	int INITIAL_STATE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_STATE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Transition</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_STATE__TRANSITION = 1;

	/**
	 * The number of structural features of the '<em>Initial State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_STATE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Initial State</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INITIAL_STATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.TransitionImpl <em>Transition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.TransitionImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTransition()
	 * @generated
	 */
	int TRANSITION = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Code Blocks</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__CODE_BLOCKS = 1;

	/**
	 * The feature id for the '<em><b>Trigger</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__TRIGGER = 2;

	/**
	 * The feature id for the '<em><b>State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__STATE = 3;

	/**
	 * The feature id for the '<em><b>Choice</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__CHOICE = 4;

	/**
	 * The feature id for the '<em><b>Deephistory</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__DEEPHISTORY = 5;

	/**
	 * The feature id for the '<em><b>Junction</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION__JUNCTION = 6;

	/**
	 * The number of structural features of the '<em>Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Transition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.ChoiceImpl <em>Choice</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.ChoiceImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getChoice()
	 * @generated
	 */
	int CHOICE = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHOICE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Trans</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHOICE__TRANS = 1;

	/**
	 * The number of structural features of the '<em>Choice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHOICE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Choice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CHOICE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.DeepHistoryImpl <em>Deep History</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.DeepHistoryImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getDeepHistory()
	 * @generated
	 */
	int DEEP_HISTORY = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEEP_HISTORY__NAME = 0;

	/**
	 * The feature id for the '<em><b>History Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEEP_HISTORY__HISTORY_TYPE = 1;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEEP_HISTORY__ACTION = 2;

	/**
	 * The feature id for the '<em><b>Trans</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEEP_HISTORY__TRANS = 3;

	/**
	 * The number of structural features of the '<em>Deep History</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEEP_HISTORY_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Deep History</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEEP_HISTORY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.JunctionImpl <em>Junction</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.JunctionImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getJunction()
	 * @generated
	 */
	int JUNCTION = 20;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JUNCTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Trans</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JUNCTION__TRANS = 1;

	/**
	 * The number of structural features of the '<em>Junction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JUNCTION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Junction</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int JUNCTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.TriggerImpl <em>Trigger</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.TriggerImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTrigger()
	 * @generated
	 */
	int TRIGGER = 21;

	/**
	 * The feature id for the '<em><b>Ports</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER__PORTS = 0;

	/**
	 * The feature id for the '<em><b>Outmessage</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER__OUTMESSAGE = 1;

	/**
	 * The feature id for the '<em><b>Inoutmessage</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER__INOUTMESSAGE = 2;

	/**
	 * The feature id for the '<em><b>Inmessage</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER__INMESSAGE = 3;

	/**
	 * The number of structural features of the '<em>Trigger</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Trigger</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIGGER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.TransImpl <em>Trans</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.TransImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTrans()
	 * @generated
	 */
	int TRANS = 22;

	/**
	 * The feature id for the '<em><b>Guard</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANS__GUARD = 0;

	/**
	 * The feature id for the '<em><b>Target</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANS__TARGET = 1;

	/**
	 * The feature id for the '<em><b>Action</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANS__ACTION = 2;

	/**
	 * The feature id for the '<em><b>State</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANS__STATE = 3;

	/**
	 * The number of structural features of the '<em>Trans</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANS_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Trans</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link papyrusrt.impl.PapyrusRTModelImpl <em>Papyrus RT Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see papyrusrt.impl.PapyrusRTModelImpl
	 * @see papyrusrt.impl.PapyrusrtPackageImpl#getPapyrusRTModel()
	 * @generated
	 */
	int PAPYRUS_RT_MODEL = 23;

	/**
	 * The feature id for the '<em><b>Protocol</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__PROTOCOL = 0;

	/**
	 * The feature id for the '<em><b>Topcapsule</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__TOPCAPSULE = 1;

	/**
	 * The feature id for the '<em><b>Statemachine</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__STATEMACHINE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__NAME = 3;

	/**
	 * The feature id for the '<em><b>Capsulepart</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__CAPSULEPART = 4;

	/**
	 * The feature id for the '<em><b>Initialstate</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__INITIALSTATE = 5;

	/**
	 * The feature id for the '<em><b>State</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__STATE = 6;

	/**
	 * The feature id for the '<em><b>Entrypoint</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__ENTRYPOINT = 7;

	/**
	 * The feature id for the '<em><b>Exitpoint</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__EXITPOINT = 8;

	/**
	 * The feature id for the '<em><b>Transition</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__TRANSITION = 9;

	/**
	 * The feature id for the '<em><b>Trigger</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__TRIGGER = 10;

	/**
	 * The feature id for the '<em><b>Junction</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__JUNCTION = 11;

	/**
	 * The feature id for the '<em><b>Deephistory</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__DEEPHISTORY = 12;

	/**
	 * The feature id for the '<em><b>Trans</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__TRANS = 13;

	/**
	 * The feature id for the '<em><b>Outmessage</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__OUTMESSAGE = 14;

	/**
	 * The feature id for the '<em><b>Inoutmessage</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__INOUTMESSAGE = 15;

	/**
	 * The feature id for the '<em><b>Inmessage</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__INMESSAGE = 16;

	/**
	 * The feature id for the '<em><b>Choice</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__CHOICE = 17;

	/**
	 * The feature id for the '<em><b>Port</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL__PORT = 18;

	/**
	 * The number of structural features of the '<em>Papyrus RT Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL_FEATURE_COUNT = 19;

	/**
	 * The number of operations of the '<em>Papyrus RT Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAPYRUS_RT_MODEL_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link papyrusrt.TopCapsule <em>Top Capsule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Top Capsule</em>'.
	 * @see papyrusrt.TopCapsule
	 * @generated
	 */
	EClass getTopCapsule();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.TopCapsule#getCapsulepart <em>Capsulepart</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Capsulepart</em>'.
	 * @see papyrusrt.TopCapsule#getCapsulepart()
	 * @see #getTopCapsule()
	 * @generated
	 */
	EReference getTopCapsule_Capsulepart();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.TopCapsule#getPorts <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ports</em>'.
	 * @see papyrusrt.TopCapsule#getPorts()
	 * @see #getTopCapsule()
	 * @generated
	 */
	EReference getTopCapsule_Ports();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.TopCapsule#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.TopCapsule#getName()
	 * @see #getTopCapsule()
	 * @generated
	 */
	EAttribute getTopCapsule_Name();

	/**
	 * Returns the meta object for class '{@link papyrusrt.CapsulePart <em>Capsule Part</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Capsule Part</em>'.
	 * @see papyrusrt.CapsulePart
	 * @generated
	 */
	EClass getCapsulePart();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.CapsulePart#getPorts <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ports</em>'.
	 * @see papyrusrt.CapsulePart#getPorts()
	 * @see #getCapsulePart()
	 * @generated
	 */
	EReference getCapsulePart_Ports();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.CapsulePart#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.CapsulePart#getName()
	 * @see #getCapsulePart()
	 * @generated
	 */
	EAttribute getCapsulePart_Name();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.CapsulePart#getStatemachine <em>Statemachine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Statemachine</em>'.
	 * @see papyrusrt.CapsulePart#getStatemachine()
	 * @see #getCapsulePart()
	 * @generated
	 */
	EReference getCapsulePart_Statemachine();

	/**
	 * Returns the meta object for class '{@link papyrusrt.SelectPort <em>Select Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Select Port</em>'.
	 * @see papyrusrt.SelectPort
	 * @generated
	 */
	EClass getSelectPort();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Protocol <em>Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Protocol</em>'.
	 * @see papyrusrt.Protocol
	 * @generated
	 */
	EClass getProtocol();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.Protocol#getOutmessage <em>Outmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Outmessage</em>'.
	 * @see papyrusrt.Protocol#getOutmessage()
	 * @see #getProtocol()
	 * @generated
	 */
	EReference getProtocol_Outmessage();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.Protocol#getInmessage <em>Inmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Inmessage</em>'.
	 * @see papyrusrt.Protocol#getInmessage()
	 * @see #getProtocol()
	 * @generated
	 */
	EReference getProtocol_Inmessage();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.Protocol#getInoutmessage <em>Inoutmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Inoutmessage</em>'.
	 * @see papyrusrt.Protocol#getInoutmessage()
	 * @see #getProtocol()
	 * @generated
	 */
	EReference getProtocol_Inoutmessage();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Protocol#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.Protocol#getName()
	 * @see #getProtocol()
	 * @generated
	 */
	EAttribute getProtocol_Name();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Outmessage <em>Outmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Outmessage</em>'.
	 * @see papyrusrt.Outmessage
	 * @generated
	 */
	EClass getOutmessage();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Outmessage#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.Outmessage#getName()
	 * @see #getOutmessage()
	 * @generated
	 */
	EAttribute getOutmessage_Name();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Inmessage <em>Inmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Inmessage</em>'.
	 * @see papyrusrt.Inmessage
	 * @generated
	 */
	EClass getInmessage();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Inmessage#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.Inmessage#getName()
	 * @see #getInmessage()
	 * @generated
	 */
	EAttribute getInmessage_Name();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Inoutmessage <em>Inoutmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Inoutmessage</em>'.
	 * @see papyrusrt.Inoutmessage
	 * @generated
	 */
	EClass getInoutmessage();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Inoutmessage#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.Inoutmessage#getName()
	 * @see #getInoutmessage()
	 * @generated
	 */
	EAttribute getInoutmessage_Name();

	/**
	 * Returns the meta object for class '{@link papyrusrt.ConjugatePort <em>Conjugate Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Conjugate Port</em>'.
	 * @see papyrusrt.ConjugatePort
	 * @generated
	 */
	EClass getConjugatePort();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.ConjugatePort#getProtocol <em>Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Protocol</em>'.
	 * @see papyrusrt.ConjugatePort#getProtocol()
	 * @see #getConjugatePort()
	 * @generated
	 */
	EReference getConjugatePort_Protocol();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.ConjugatePort#getNonconjugateport <em>Nonconjugateport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Nonconjugateport</em>'.
	 * @see papyrusrt.ConjugatePort#getNonconjugateport()
	 * @see #getConjugatePort()
	 * @generated
	 */
	EReference getConjugatePort_Nonconjugateport();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.ConjugatePort#getConjName <em>Conj Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Conj Name</em>'.
	 * @see papyrusrt.ConjugatePort#getConjName()
	 * @see #getConjugatePort()
	 * @generated
	 */
	EAttribute getConjugatePort_ConjName();

	/**
	 * Returns the meta object for class '{@link papyrusrt.NonconjugatePort <em>Nonconjugate Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Nonconjugate Port</em>'.
	 * @see papyrusrt.NonconjugatePort
	 * @generated
	 */
	EClass getNonconjugatePort();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.NonconjugatePort#getProtocol <em>Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Protocol</em>'.
	 * @see papyrusrt.NonconjugatePort#getProtocol()
	 * @see #getNonconjugatePort()
	 * @generated
	 */
	EReference getNonconjugatePort_Protocol();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.NonconjugatePort#getConjugateport <em>Conjugateport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Conjugateport</em>'.
	 * @see papyrusrt.NonconjugatePort#getConjugateport()
	 * @see #getNonconjugatePort()
	 * @generated
	 */
	EReference getNonconjugatePort_Conjugateport();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.NonconjugatePort#getNonConjName <em>Non Conj Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Non Conj Name</em>'.
	 * @see papyrusrt.NonconjugatePort#getNonConjName()
	 * @see #getNonconjugatePort()
	 * @generated
	 */
	EAttribute getNonconjugatePort_NonConjName();

	/**
	 * Returns the meta object for class '{@link papyrusrt.FramePort <em>Frame Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Frame Port</em>'.
	 * @see papyrusrt.FramePort
	 * @generated
	 */
	EClass getFramePort();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.FramePort#getFrameName <em>Frame Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Frame Name</em>'.
	 * @see papyrusrt.FramePort#getFrameName()
	 * @see #getFramePort()
	 * @generated
	 */
	EAttribute getFramePort_FrameName();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.FramePort#getSystemProtocol <em>System Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>System Protocol</em>'.
	 * @see papyrusrt.FramePort#getSystemProtocol()
	 * @see #getFramePort()
	 * @generated
	 */
	EAttribute getFramePort_SystemProtocol();

	/**
	 * Returns the meta object for class '{@link papyrusrt.LogPort <em>Log Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Log Port</em>'.
	 * @see papyrusrt.LogPort
	 * @generated
	 */
	EClass getLogPort();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.LogPort#getLogName <em>Log Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Log Name</em>'.
	 * @see papyrusrt.LogPort#getLogName()
	 * @see #getLogPort()
	 * @generated
	 */
	EAttribute getLogPort_LogName();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.LogPort#getSystemProtocol <em>System Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>System Protocol</em>'.
	 * @see papyrusrt.LogPort#getSystemProtocol()
	 * @see #getLogPort()
	 * @generated
	 */
	EAttribute getLogPort_SystemProtocol();

	/**
	 * Returns the meta object for class '{@link papyrusrt.TimingPort <em>Timing Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Timing Port</em>'.
	 * @see papyrusrt.TimingPort
	 * @generated
	 */
	EClass getTimingPort();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.TimingPort#getTimingName <em>Timing Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Timing Name</em>'.
	 * @see papyrusrt.TimingPort#getTimingName()
	 * @see #getTimingPort()
	 * @generated
	 */
	EAttribute getTimingPort_TimingName();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.TimingPort#getSystemProtocol <em>System Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>System Protocol</em>'.
	 * @see papyrusrt.TimingPort#getSystemProtocol()
	 * @see #getTimingPort()
	 * @generated
	 */
	EAttribute getTimingPort_SystemProtocol();

	/**
	 * Returns the meta object for class '{@link papyrusrt.StateMachine <em>State Machine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State Machine</em>'.
	 * @see papyrusrt.StateMachine
	 * @generated
	 */
	EClass getStateMachine();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.StateMachine#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.StateMachine#getName()
	 * @see #getStateMachine()
	 * @generated
	 */
	EAttribute getStateMachine_Name();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.StateMachine#getRegion <em>Region</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Region</em>'.
	 * @see papyrusrt.StateMachine#getRegion()
	 * @see #getStateMachine()
	 * @generated
	 */
	EAttribute getStateMachine_Region();

	/**
	 * Returns the meta object for the containment reference '{@link papyrusrt.StateMachine#getInitialstate <em>Initialstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Initialstate</em>'.
	 * @see papyrusrt.StateMachine#getInitialstate()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_Initialstate();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.StateMachine#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>State</em>'.
	 * @see papyrusrt.StateMachine#getState()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_State();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.StateMachine#getTransition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transition</em>'.
	 * @see papyrusrt.StateMachine#getTransition()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_Transition();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.StateMachine#getChoice <em>Choice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Choice</em>'.
	 * @see papyrusrt.StateMachine#getChoice()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_Choice();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.StateMachine#getDeephistory <em>Deephistory</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Deephistory</em>'.
	 * @see papyrusrt.StateMachine#getDeephistory()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_Deephistory();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.StateMachine#getJunction <em>Junction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Junction</em>'.
	 * @see papyrusrt.StateMachine#getJunction()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_Junction();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.StateMachine#getTrans <em>Trans</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Trans</em>'.
	 * @see papyrusrt.StateMachine#getTrans()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_Trans();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.StateMachine#getExitpoint <em>Exitpoint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Exitpoint</em>'.
	 * @see papyrusrt.StateMachine#getExitpoint()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_Exitpoint();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.StateMachine#getEntrypoint <em>Entrypoint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Entrypoint</em>'.
	 * @see papyrusrt.StateMachine#getEntrypoint()
	 * @see #getStateMachine()
	 * @generated
	 */
	EReference getStateMachine_Entrypoint();

	/**
	 * Returns the meta object for class '{@link papyrusrt.State <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>State</em>'.
	 * @see papyrusrt.State
	 * @generated
	 */
	EClass getState();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.State#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.State#getName()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_Name();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.State#getEntryAction <em>Entry Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Entry Action</em>'.
	 * @see papyrusrt.State#getEntryAction()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_EntryAction();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.State#getExitAction <em>Exit Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Exit Action</em>'.
	 * @see papyrusrt.State#getExitAction()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_ExitAction();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.State#getInternalTransition <em>Internal Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Internal Transition</em>'.
	 * @see papyrusrt.State#getInternalTransition()
	 * @see #getState()
	 * @generated
	 */
	EAttribute getState_InternalTransition();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.State#getEntrypoint <em>Entrypoint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Entrypoint</em>'.
	 * @see papyrusrt.State#getEntrypoint()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_Entrypoint();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.State#getExitpoint <em>Exitpoint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Exitpoint</em>'.
	 * @see papyrusrt.State#getExitpoint()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_Exitpoint();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.State#getTransition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Transition</em>'.
	 * @see papyrusrt.State#getTransition()
	 * @see #getState()
	 * @generated
	 */
	EReference getState_Transition();

	/**
	 * Returns the meta object for class '{@link papyrusrt.EntryPoint <em>Entry Point</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entry Point</em>'.
	 * @see papyrusrt.EntryPoint
	 * @generated
	 */
	EClass getEntryPoint();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.EntryPoint#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.EntryPoint#getName()
	 * @see #getEntryPoint()
	 * @generated
	 */
	EAttribute getEntryPoint_Name();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.EntryPoint#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see papyrusrt.EntryPoint#getLabel()
	 * @see #getEntryPoint()
	 * @generated
	 */
	EAttribute getEntryPoint_Label();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.EntryPoint#getKind <em>Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Kind</em>'.
	 * @see papyrusrt.EntryPoint#getKind()
	 * @see #getEntryPoint()
	 * @generated
	 */
	EAttribute getEntryPoint_Kind();

	/**
	 * Returns the meta object for class '{@link papyrusrt.ExitPoint <em>Exit Point</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Exit Point</em>'.
	 * @see papyrusrt.ExitPoint
	 * @generated
	 */
	EClass getExitPoint();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.ExitPoint#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.ExitPoint#getName()
	 * @see #getExitPoint()
	 * @generated
	 */
	EAttribute getExitPoint_Name();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.ExitPoint#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see papyrusrt.ExitPoint#getLabel()
	 * @see #getExitPoint()
	 * @generated
	 */
	EAttribute getExitPoint_Label();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.ExitPoint#getKind <em>Kind</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Kind</em>'.
	 * @see papyrusrt.ExitPoint#getKind()
	 * @see #getExitPoint()
	 * @generated
	 */
	EAttribute getExitPoint_Kind();

	/**
	 * Returns the meta object for class '{@link papyrusrt.InitialState <em>Initial State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Initial State</em>'.
	 * @see papyrusrt.InitialState
	 * @generated
	 */
	EClass getInitialState();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.InitialState#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.InitialState#getName()
	 * @see #getInitialState()
	 * @generated
	 */
	EAttribute getInitialState_Name();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.InitialState#getTransition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Transition</em>'.
	 * @see papyrusrt.InitialState#getTransition()
	 * @see #getInitialState()
	 * @generated
	 */
	EReference getInitialState_Transition();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Transition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transition</em>'.
	 * @see papyrusrt.Transition
	 * @generated
	 */
	EClass getTransition();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Transition#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.Transition#getName()
	 * @see #getTransition()
	 * @generated
	 */
	EAttribute getTransition_Name();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Transition#getCodeBlocks <em>Code Blocks</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Code Blocks</em>'.
	 * @see papyrusrt.Transition#getCodeBlocks()
	 * @see #getTransition()
	 * @generated
	 */
	EAttribute getTransition_CodeBlocks();

	/**
	 * Returns the meta object for the containment reference '{@link papyrusrt.Transition#getTrigger <em>Trigger</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Trigger</em>'.
	 * @see papyrusrt.Transition#getTrigger()
	 * @see #getTransition()
	 * @generated
	 */
	EReference getTransition_Trigger();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.Transition#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>State</em>'.
	 * @see papyrusrt.Transition#getState()
	 * @see #getTransition()
	 * @generated
	 */
	EReference getTransition_State();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.Transition#getChoice <em>Choice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Choice</em>'.
	 * @see papyrusrt.Transition#getChoice()
	 * @see #getTransition()
	 * @generated
	 */
	EReference getTransition_Choice();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.Transition#getDeephistory <em>Deephistory</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Deephistory</em>'.
	 * @see papyrusrt.Transition#getDeephistory()
	 * @see #getTransition()
	 * @generated
	 */
	EReference getTransition_Deephistory();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.Transition#getJunction <em>Junction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Junction</em>'.
	 * @see papyrusrt.Transition#getJunction()
	 * @see #getTransition()
	 * @generated
	 */
	EReference getTransition_Junction();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Choice <em>Choice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Choice</em>'.
	 * @see papyrusrt.Choice
	 * @generated
	 */
	EClass getChoice();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Choice#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.Choice#getName()
	 * @see #getChoice()
	 * @generated
	 */
	EAttribute getChoice_Name();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.Choice#getTrans <em>Trans</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Trans</em>'.
	 * @see papyrusrt.Choice#getTrans()
	 * @see #getChoice()
	 * @generated
	 */
	EReference getChoice_Trans();

	/**
	 * Returns the meta object for class '{@link papyrusrt.DeepHistory <em>Deep History</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Deep History</em>'.
	 * @see papyrusrt.DeepHistory
	 * @generated
	 */
	EClass getDeepHistory();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.DeepHistory#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.DeepHistory#getName()
	 * @see #getDeepHistory()
	 * @generated
	 */
	EAttribute getDeepHistory_Name();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.DeepHistory#getHistoryType <em>History Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>History Type</em>'.
	 * @see papyrusrt.DeepHistory#getHistoryType()
	 * @see #getDeepHistory()
	 * @generated
	 */
	EAttribute getDeepHistory_HistoryType();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.DeepHistory#getAction <em>Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Action</em>'.
	 * @see papyrusrt.DeepHistory#getAction()
	 * @see #getDeepHistory()
	 * @generated
	 */
	EAttribute getDeepHistory_Action();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.DeepHistory#getTrans <em>Trans</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Trans</em>'.
	 * @see papyrusrt.DeepHistory#getTrans()
	 * @see #getDeepHistory()
	 * @generated
	 */
	EReference getDeepHistory_Trans();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Junction <em>Junction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Junction</em>'.
	 * @see papyrusrt.Junction
	 * @generated
	 */
	EClass getJunction();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Junction#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.Junction#getName()
	 * @see #getJunction()
	 * @generated
	 */
	EAttribute getJunction_Name();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.Junction#getTrans <em>Trans</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Trans</em>'.
	 * @see papyrusrt.Junction#getTrans()
	 * @see #getJunction()
	 * @generated
	 */
	EReference getJunction_Trans();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Trigger <em>Trigger</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trigger</em>'.
	 * @see papyrusrt.Trigger
	 * @generated
	 */
	EClass getTrigger();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.Trigger#getPorts <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ports</em>'.
	 * @see papyrusrt.Trigger#getPorts()
	 * @see #getTrigger()
	 * @generated
	 */
	EReference getTrigger_Ports();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.Trigger#getOutmessage <em>Outmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Outmessage</em>'.
	 * @see papyrusrt.Trigger#getOutmessage()
	 * @see #getTrigger()
	 * @generated
	 */
	EReference getTrigger_Outmessage();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.Trigger#getInoutmessage <em>Inoutmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Inoutmessage</em>'.
	 * @see papyrusrt.Trigger#getInoutmessage()
	 * @see #getTrigger()
	 * @generated
	 */
	EReference getTrigger_Inoutmessage();

	/**
	 * Returns the meta object for the reference list '{@link papyrusrt.Trigger#getInmessage <em>Inmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Inmessage</em>'.
	 * @see papyrusrt.Trigger#getInmessage()
	 * @see #getTrigger()
	 * @generated
	 */
	EReference getTrigger_Inmessage();

	/**
	 * Returns the meta object for class '{@link papyrusrt.Trans <em>Trans</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trans</em>'.
	 * @see papyrusrt.Trans
	 * @generated
	 */
	EClass getTrans();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Trans#getGuard <em>Guard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Guard</em>'.
	 * @see papyrusrt.Trans#getGuard()
	 * @see #getTrans()
	 * @generated
	 */
	EAttribute getTrans_Guard();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Trans#getTarget <em>Target</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Target</em>'.
	 * @see papyrusrt.Trans#getTarget()
	 * @see #getTrans()
	 * @generated
	 */
	EAttribute getTrans_Target();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.Trans#getAction <em>Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Action</em>'.
	 * @see papyrusrt.Trans#getAction()
	 * @see #getTrans()
	 * @generated
	 */
	EAttribute getTrans_Action();

	/**
	 * Returns the meta object for the reference '{@link papyrusrt.Trans#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>State</em>'.
	 * @see papyrusrt.Trans#getState()
	 * @see #getTrans()
	 * @generated
	 */
	EReference getTrans_State();

	/**
	 * Returns the meta object for class '{@link papyrusrt.PapyrusRTModel <em>Papyrus RT Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Papyrus RT Model</em>'.
	 * @see papyrusrt.PapyrusRTModel
	 * @generated
	 */
	EClass getPapyrusRTModel();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getProtocol <em>Protocol</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Protocol</em>'.
	 * @see papyrusrt.PapyrusRTModel#getProtocol()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Protocol();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getTopcapsule <em>Topcapsule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Topcapsule</em>'.
	 * @see papyrusrt.PapyrusRTModel#getTopcapsule()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Topcapsule();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getStatemachine <em>Statemachine</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Statemachine</em>'.
	 * @see papyrusrt.PapyrusRTModel#getStatemachine()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Statemachine();

	/**
	 * Returns the meta object for the attribute '{@link papyrusrt.PapyrusRTModel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see papyrusrt.PapyrusRTModel#getName()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EAttribute getPapyrusRTModel_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getCapsulepart <em>Capsulepart</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Capsulepart</em>'.
	 * @see papyrusrt.PapyrusRTModel#getCapsulepart()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Capsulepart();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getInitialstate <em>Initialstate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Initialstate</em>'.
	 * @see papyrusrt.PapyrusRTModel#getInitialstate()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Initialstate();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getState <em>State</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>State</em>'.
	 * @see papyrusrt.PapyrusRTModel#getState()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_State();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getEntrypoint <em>Entrypoint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Entrypoint</em>'.
	 * @see papyrusrt.PapyrusRTModel#getEntrypoint()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Entrypoint();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getExitpoint <em>Exitpoint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Exitpoint</em>'.
	 * @see papyrusrt.PapyrusRTModel#getExitpoint()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Exitpoint();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getTransition <em>Transition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Transition</em>'.
	 * @see papyrusrt.PapyrusRTModel#getTransition()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Transition();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getTrigger <em>Trigger</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Trigger</em>'.
	 * @see papyrusrt.PapyrusRTModel#getTrigger()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Trigger();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getJunction <em>Junction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Junction</em>'.
	 * @see papyrusrt.PapyrusRTModel#getJunction()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Junction();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getDeephistory <em>Deephistory</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Deephistory</em>'.
	 * @see papyrusrt.PapyrusRTModel#getDeephistory()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Deephistory();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getTrans <em>Trans</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Trans</em>'.
	 * @see papyrusrt.PapyrusRTModel#getTrans()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Trans();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getOutmessage <em>Outmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Outmessage</em>'.
	 * @see papyrusrt.PapyrusRTModel#getOutmessage()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Outmessage();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getInoutmessage <em>Inoutmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Inoutmessage</em>'.
	 * @see papyrusrt.PapyrusRTModel#getInoutmessage()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Inoutmessage();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getInmessage <em>Inmessage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Inmessage</em>'.
	 * @see papyrusrt.PapyrusRTModel#getInmessage()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Inmessage();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getChoice <em>Choice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Choice</em>'.
	 * @see papyrusrt.PapyrusRTModel#getChoice()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Choice();

	/**
	 * Returns the meta object for the containment reference list '{@link papyrusrt.PapyrusRTModel#getPort <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Port</em>'.
	 * @see papyrusrt.PapyrusRTModel#getPort()
	 * @see #getPapyrusRTModel()
	 * @generated
	 */
	EReference getPapyrusRTModel_Port();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	PapyrusrtFactory getPapyrusrtFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link papyrusrt.impl.TopCapsuleImpl <em>Top Capsule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.TopCapsuleImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTopCapsule()
		 * @generated
		 */
		EClass TOP_CAPSULE = eINSTANCE.getTopCapsule();

		/**
		 * The meta object literal for the '<em><b>Capsulepart</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_CAPSULE__CAPSULEPART = eINSTANCE.getTopCapsule_Capsulepart();

		/**
		 * The meta object literal for the '<em><b>Ports</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TOP_CAPSULE__PORTS = eINSTANCE.getTopCapsule_Ports();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TOP_CAPSULE__NAME = eINSTANCE.getTopCapsule_Name();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.CapsulePartImpl <em>Capsule Part</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.CapsulePartImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getCapsulePart()
		 * @generated
		 */
		EClass CAPSULE_PART = eINSTANCE.getCapsulePart();

		/**
		 * The meta object literal for the '<em><b>Ports</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CAPSULE_PART__PORTS = eINSTANCE.getCapsulePart_Ports();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CAPSULE_PART__NAME = eINSTANCE.getCapsulePart_Name();

		/**
		 * The meta object literal for the '<em><b>Statemachine</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CAPSULE_PART__STATEMACHINE = eINSTANCE.getCapsulePart_Statemachine();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.SelectPortImpl <em>Select Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.SelectPortImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getSelectPort()
		 * @generated
		 */
		EClass SELECT_PORT = eINSTANCE.getSelectPort();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.ProtocolImpl <em>Protocol</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.ProtocolImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getProtocol()
		 * @generated
		 */
		EClass PROTOCOL = eINSTANCE.getProtocol();

		/**
		 * The meta object literal for the '<em><b>Outmessage</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROTOCOL__OUTMESSAGE = eINSTANCE.getProtocol_Outmessage();

		/**
		 * The meta object literal for the '<em><b>Inmessage</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROTOCOL__INMESSAGE = eINSTANCE.getProtocol_Inmessage();

		/**
		 * The meta object literal for the '<em><b>Inoutmessage</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROTOCOL__INOUTMESSAGE = eINSTANCE.getProtocol_Inoutmessage();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROTOCOL__NAME = eINSTANCE.getProtocol_Name();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.OutmessageImpl <em>Outmessage</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.OutmessageImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getOutmessage()
		 * @generated
		 */
		EClass OUTMESSAGE = eINSTANCE.getOutmessage();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OUTMESSAGE__NAME = eINSTANCE.getOutmessage_Name();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.InmessageImpl <em>Inmessage</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.InmessageImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getInmessage()
		 * @generated
		 */
		EClass INMESSAGE = eINSTANCE.getInmessage();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INMESSAGE__NAME = eINSTANCE.getInmessage_Name();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.InoutmessageImpl <em>Inoutmessage</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.InoutmessageImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getInoutmessage()
		 * @generated
		 */
		EClass INOUTMESSAGE = eINSTANCE.getInoutmessage();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INOUTMESSAGE__NAME = eINSTANCE.getInoutmessage_Name();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.ConjugatePortImpl <em>Conjugate Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.ConjugatePortImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getConjugatePort()
		 * @generated
		 */
		EClass CONJUGATE_PORT = eINSTANCE.getConjugatePort();

		/**
		 * The meta object literal for the '<em><b>Protocol</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONJUGATE_PORT__PROTOCOL = eINSTANCE.getConjugatePort_Protocol();

		/**
		 * The meta object literal for the '<em><b>Nonconjugateport</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONJUGATE_PORT__NONCONJUGATEPORT = eINSTANCE.getConjugatePort_Nonconjugateport();

		/**
		 * The meta object literal for the '<em><b>Conj Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONJUGATE_PORT__CONJ_NAME = eINSTANCE.getConjugatePort_ConjName();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.NonconjugatePortImpl <em>Nonconjugate Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.NonconjugatePortImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getNonconjugatePort()
		 * @generated
		 */
		EClass NONCONJUGATE_PORT = eINSTANCE.getNonconjugatePort();

		/**
		 * The meta object literal for the '<em><b>Protocol</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NONCONJUGATE_PORT__PROTOCOL = eINSTANCE.getNonconjugatePort_Protocol();

		/**
		 * The meta object literal for the '<em><b>Conjugateport</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NONCONJUGATE_PORT__CONJUGATEPORT = eINSTANCE.getNonconjugatePort_Conjugateport();

		/**
		 * The meta object literal for the '<em><b>Non Conj Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NONCONJUGATE_PORT__NON_CONJ_NAME = eINSTANCE.getNonconjugatePort_NonConjName();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.FramePortImpl <em>Frame Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.FramePortImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getFramePort()
		 * @generated
		 */
		EClass FRAME_PORT = eINSTANCE.getFramePort();

		/**
		 * The meta object literal for the '<em><b>Frame Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FRAME_PORT__FRAME_NAME = eINSTANCE.getFramePort_FrameName();

		/**
		 * The meta object literal for the '<em><b>System Protocol</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FRAME_PORT__SYSTEM_PROTOCOL = eINSTANCE.getFramePort_SystemProtocol();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.LogPortImpl <em>Log Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.LogPortImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getLogPort()
		 * @generated
		 */
		EClass LOG_PORT = eINSTANCE.getLogPort();

		/**
		 * The meta object literal for the '<em><b>Log Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOG_PORT__LOG_NAME = eINSTANCE.getLogPort_LogName();

		/**
		 * The meta object literal for the '<em><b>System Protocol</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LOG_PORT__SYSTEM_PROTOCOL = eINSTANCE.getLogPort_SystemProtocol();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.TimingPortImpl <em>Timing Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.TimingPortImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTimingPort()
		 * @generated
		 */
		EClass TIMING_PORT = eINSTANCE.getTimingPort();

		/**
		 * The meta object literal for the '<em><b>Timing Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIMING_PORT__TIMING_NAME = eINSTANCE.getTimingPort_TimingName();

		/**
		 * The meta object literal for the '<em><b>System Protocol</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIMING_PORT__SYSTEM_PROTOCOL = eINSTANCE.getTimingPort_SystemProtocol();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.StateMachineImpl <em>State Machine</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.StateMachineImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getStateMachine()
		 * @generated
		 */
		EClass STATE_MACHINE = eINSTANCE.getStateMachine();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE_MACHINE__NAME = eINSTANCE.getStateMachine_Name();

		/**
		 * The meta object literal for the '<em><b>Region</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE_MACHINE__REGION = eINSTANCE.getStateMachine_Region();

		/**
		 * The meta object literal for the '<em><b>Initialstate</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__INITIALSTATE = eINSTANCE.getStateMachine_Initialstate();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__STATE = eINSTANCE.getStateMachine_State();

		/**
		 * The meta object literal for the '<em><b>Transition</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__TRANSITION = eINSTANCE.getStateMachine_Transition();

		/**
		 * The meta object literal for the '<em><b>Choice</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__CHOICE = eINSTANCE.getStateMachine_Choice();

		/**
		 * The meta object literal for the '<em><b>Deephistory</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__DEEPHISTORY = eINSTANCE.getStateMachine_Deephistory();

		/**
		 * The meta object literal for the '<em><b>Junction</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__JUNCTION = eINSTANCE.getStateMachine_Junction();

		/**
		 * The meta object literal for the '<em><b>Trans</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__TRANS = eINSTANCE.getStateMachine_Trans();

		/**
		 * The meta object literal for the '<em><b>Exitpoint</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__EXITPOINT = eINSTANCE.getStateMachine_Exitpoint();

		/**
		 * The meta object literal for the '<em><b>Entrypoint</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE_MACHINE__ENTRYPOINT = eINSTANCE.getStateMachine_Entrypoint();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.StateImpl <em>State</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.StateImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getState()
		 * @generated
		 */
		EClass STATE = eINSTANCE.getState();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__NAME = eINSTANCE.getState_Name();

		/**
		 * The meta object literal for the '<em><b>Entry Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__ENTRY_ACTION = eINSTANCE.getState_EntryAction();

		/**
		 * The meta object literal for the '<em><b>Exit Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__EXIT_ACTION = eINSTANCE.getState_ExitAction();

		/**
		 * The meta object literal for the '<em><b>Internal Transition</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STATE__INTERNAL_TRANSITION = eINSTANCE.getState_InternalTransition();

		/**
		 * The meta object literal for the '<em><b>Entrypoint</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__ENTRYPOINT = eINSTANCE.getState_Entrypoint();

		/**
		 * The meta object literal for the '<em><b>Exitpoint</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__EXITPOINT = eINSTANCE.getState_Exitpoint();

		/**
		 * The meta object literal for the '<em><b>Transition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STATE__TRANSITION = eINSTANCE.getState_Transition();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.EntryPointImpl <em>Entry Point</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.EntryPointImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getEntryPoint()
		 * @generated
		 */
		EClass ENTRY_POINT = eINSTANCE.getEntryPoint();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTRY_POINT__NAME = eINSTANCE.getEntryPoint_Name();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTRY_POINT__LABEL = eINSTANCE.getEntryPoint_Label();

		/**
		 * The meta object literal for the '<em><b>Kind</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTRY_POINT__KIND = eINSTANCE.getEntryPoint_Kind();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.ExitPointImpl <em>Exit Point</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.ExitPointImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getExitPoint()
		 * @generated
		 */
		EClass EXIT_POINT = eINSTANCE.getExitPoint();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXIT_POINT__NAME = eINSTANCE.getExitPoint_Name();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXIT_POINT__LABEL = eINSTANCE.getExitPoint_Label();

		/**
		 * The meta object literal for the '<em><b>Kind</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXIT_POINT__KIND = eINSTANCE.getExitPoint_Kind();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.InitialStateImpl <em>Initial State</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.InitialStateImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getInitialState()
		 * @generated
		 */
		EClass INITIAL_STATE = eINSTANCE.getInitialState();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INITIAL_STATE__NAME = eINSTANCE.getInitialState_Name();

		/**
		 * The meta object literal for the '<em><b>Transition</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INITIAL_STATE__TRANSITION = eINSTANCE.getInitialState_Transition();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.TransitionImpl <em>Transition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.TransitionImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTransition()
		 * @generated
		 */
		EClass TRANSITION = eINSTANCE.getTransition();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSITION__NAME = eINSTANCE.getTransition_Name();

		/**
		 * The meta object literal for the '<em><b>Code Blocks</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSITION__CODE_BLOCKS = eINSTANCE.getTransition_CodeBlocks();

		/**
		 * The meta object literal for the '<em><b>Trigger</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__TRIGGER = eINSTANCE.getTransition_Trigger();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__STATE = eINSTANCE.getTransition_State();

		/**
		 * The meta object literal for the '<em><b>Choice</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__CHOICE = eINSTANCE.getTransition_Choice();

		/**
		 * The meta object literal for the '<em><b>Deephistory</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__DEEPHISTORY = eINSTANCE.getTransition_Deephistory();

		/**
		 * The meta object literal for the '<em><b>Junction</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSITION__JUNCTION = eINSTANCE.getTransition_Junction();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.ChoiceImpl <em>Choice</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.ChoiceImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getChoice()
		 * @generated
		 */
		EClass CHOICE = eINSTANCE.getChoice();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CHOICE__NAME = eINSTANCE.getChoice_Name();

		/**
		 * The meta object literal for the '<em><b>Trans</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CHOICE__TRANS = eINSTANCE.getChoice_Trans();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.DeepHistoryImpl <em>Deep History</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.DeepHistoryImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getDeepHistory()
		 * @generated
		 */
		EClass DEEP_HISTORY = eINSTANCE.getDeepHistory();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEEP_HISTORY__NAME = eINSTANCE.getDeepHistory_Name();

		/**
		 * The meta object literal for the '<em><b>History Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEEP_HISTORY__HISTORY_TYPE = eINSTANCE.getDeepHistory_HistoryType();

		/**
		 * The meta object literal for the '<em><b>Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DEEP_HISTORY__ACTION = eINSTANCE.getDeepHistory_Action();

		/**
		 * The meta object literal for the '<em><b>Trans</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEEP_HISTORY__TRANS = eINSTANCE.getDeepHistory_Trans();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.JunctionImpl <em>Junction</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.JunctionImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getJunction()
		 * @generated
		 */
		EClass JUNCTION = eINSTANCE.getJunction();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute JUNCTION__NAME = eINSTANCE.getJunction_Name();

		/**
		 * The meta object literal for the '<em><b>Trans</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference JUNCTION__TRANS = eINSTANCE.getJunction_Trans();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.TriggerImpl <em>Trigger</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.TriggerImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTrigger()
		 * @generated
		 */
		EClass TRIGGER = eINSTANCE.getTrigger();

		/**
		 * The meta object literal for the '<em><b>Ports</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIGGER__PORTS = eINSTANCE.getTrigger_Ports();

		/**
		 * The meta object literal for the '<em><b>Outmessage</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIGGER__OUTMESSAGE = eINSTANCE.getTrigger_Outmessage();

		/**
		 * The meta object literal for the '<em><b>Inoutmessage</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIGGER__INOUTMESSAGE = eINSTANCE.getTrigger_Inoutmessage();

		/**
		 * The meta object literal for the '<em><b>Inmessage</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIGGER__INMESSAGE = eINSTANCE.getTrigger_Inmessage();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.TransImpl <em>Trans</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.TransImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getTrans()
		 * @generated
		 */
		EClass TRANS = eINSTANCE.getTrans();

		/**
		 * The meta object literal for the '<em><b>Guard</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANS__GUARD = eINSTANCE.getTrans_Guard();

		/**
		 * The meta object literal for the '<em><b>Target</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANS__TARGET = eINSTANCE.getTrans_Target();

		/**
		 * The meta object literal for the '<em><b>Action</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANS__ACTION = eINSTANCE.getTrans_Action();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANS__STATE = eINSTANCE.getTrans_State();

		/**
		 * The meta object literal for the '{@link papyrusrt.impl.PapyrusRTModelImpl <em>Papyrus RT Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see papyrusrt.impl.PapyrusRTModelImpl
		 * @see papyrusrt.impl.PapyrusrtPackageImpl#getPapyrusRTModel()
		 * @generated
		 */
		EClass PAPYRUS_RT_MODEL = eINSTANCE.getPapyrusRTModel();

		/**
		 * The meta object literal for the '<em><b>Protocol</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__PROTOCOL = eINSTANCE.getPapyrusRTModel_Protocol();

		/**
		 * The meta object literal for the '<em><b>Topcapsule</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__TOPCAPSULE = eINSTANCE.getPapyrusRTModel_Topcapsule();

		/**
		 * The meta object literal for the '<em><b>Statemachine</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__STATEMACHINE = eINSTANCE.getPapyrusRTModel_Statemachine();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAPYRUS_RT_MODEL__NAME = eINSTANCE.getPapyrusRTModel_Name();

		/**
		 * The meta object literal for the '<em><b>Capsulepart</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__CAPSULEPART = eINSTANCE.getPapyrusRTModel_Capsulepart();

		/**
		 * The meta object literal for the '<em><b>Initialstate</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__INITIALSTATE = eINSTANCE.getPapyrusRTModel_Initialstate();

		/**
		 * The meta object literal for the '<em><b>State</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__STATE = eINSTANCE.getPapyrusRTModel_State();

		/**
		 * The meta object literal for the '<em><b>Entrypoint</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__ENTRYPOINT = eINSTANCE.getPapyrusRTModel_Entrypoint();

		/**
		 * The meta object literal for the '<em><b>Exitpoint</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__EXITPOINT = eINSTANCE.getPapyrusRTModel_Exitpoint();

		/**
		 * The meta object literal for the '<em><b>Transition</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__TRANSITION = eINSTANCE.getPapyrusRTModel_Transition();

		/**
		 * The meta object literal for the '<em><b>Trigger</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__TRIGGER = eINSTANCE.getPapyrusRTModel_Trigger();

		/**
		 * The meta object literal for the '<em><b>Junction</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__JUNCTION = eINSTANCE.getPapyrusRTModel_Junction();

		/**
		 * The meta object literal for the '<em><b>Deephistory</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__DEEPHISTORY = eINSTANCE.getPapyrusRTModel_Deephistory();

		/**
		 * The meta object literal for the '<em><b>Trans</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__TRANS = eINSTANCE.getPapyrusRTModel_Trans();

		/**
		 * The meta object literal for the '<em><b>Outmessage</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__OUTMESSAGE = eINSTANCE.getPapyrusRTModel_Outmessage();

		/**
		 * The meta object literal for the '<em><b>Inoutmessage</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__INOUTMESSAGE = eINSTANCE.getPapyrusRTModel_Inoutmessage();

		/**
		 * The meta object literal for the '<em><b>Inmessage</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__INMESSAGE = eINSTANCE.getPapyrusRTModel_Inmessage();

		/**
		 * The meta object literal for the '<em><b>Choice</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__CHOICE = eINSTANCE.getPapyrusRTModel_Choice();

		/**
		 * The meta object literal for the '<em><b>Port</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAPYRUS_RT_MODEL__PORT = eINSTANCE.getPapyrusRTModel_Port();

	}

} //PapyrusrtPackage
